clear all; clc; close all;
load foo;


Matrix_values=[];
% CL = 0.8;

multiple=str2double(answer(1));
Npoints=str2double(answer(2));
initial_value=str2double(answer(3));
final_value=str2double(answer(4));

if multiple==0   
    dumb_loop=2;
    CL_vector=[initial_value final_value];
    
elseif multiple==1  
    dumb_loop=Npoints;
    
    intervals_in_between=(final_value-initial_value)/(Npoints-1);
    
    
    CL_vector=initial_value:intervals_in_between:final_value;
    
else  % it just calculates the   
    dumb_loop=2; 
end

%%%% Karim starts %%%%%

for jjj=1:dumb_loop

    CL =CL_vector(jjj);
    
    ResulrMat = [];
    Res_cnt = 1;
    FileList = dir;
    FileList(1:2,:)=[];
    FolderList
    DirLstL_0 = DirName;


        a = cd;
        b = strcat(a,'\',DirLstL_0);

        FileList = dir(cell2mat(b));
        FileList(1:2,:)=[];
        FolderList
        DirLstL_1{1} = [b, DirName];



    Lp_Dir_lst = DirLstL_1;
    
    for Lv = 1:7
        
    DirLstL_Int = []; 

        for Clp2 = 1:size(Lp_Dir_lst,1)
            for Lp2 = 2:length(Lp_Dir_lst{Clp2,1})
                   DirName=[];
                   d = strcat(Lp_Dir_lst{Clp2,1}(1),'\',Lp_Dir_lst{Clp2,1}(Lp2));

            FileList = dir(cell2mat(d))
            FileList(1:2,:)=[];



            FolderList

            if isempty(DirName)==1
            continue
            end

            DirLstL_trans{Lp2-1,1} = [d, DirName]
            end
            DirLstL_Int = [DirLstL_Int;DirLstL_trans];
            DirLstL_trans= [];
        end

    %===============  Step 2.1  ======================================= 

    Lp_Dir_lst = DirLstL_Int;

    end


    ResulrMat;
    
    Matrix_values(:,:,jjj)=ResulrMat;


end
    