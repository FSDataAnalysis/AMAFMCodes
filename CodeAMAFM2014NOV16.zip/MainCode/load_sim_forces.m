% clear all
% close all
% clc
%%%% This asks you to load the file where the force is %%%%%%
[filename_2, pathname_2,filterindex_2] = uigetfile({'*.txt'},'File Selector_2');
if isequal(filename_2,0)
return
elseif isequal(filterindex_2,1)
    Data_sim=load ([pathname_2,'\',filename_2]);
end
%% %%%%%%%%%%%%%
% t,				// 1
% d,				// 2
% Fts,				// 3
% ZcT,				// 4
% F_approach_retract, // 5
% Fvct,				// 6		
% Fvnc				// 7
%
% count_figures=0;

Force_simulation_minima=min(Data_sim((length(Data_sim(:,1))-20000):(length(Data_sim(:,1))), 5));
abs_Force_simulation_minima=abs(Force_simulation_minima);

Distance_simulation=Data_sim(end-18000:end,2);
Force_net_simulation=Data_sim(end-18000:end,3);
Force_appr_retr_simulation=Data_sim(end-18000:end,5);
Force_vis_c_simulation=Data_sim(end-18000:end,6);
Force_vis_nc_simulation=Data_sim(end-18000:end,7);


Maxima_viscosity_contact=max(Force_vis_c_simulation);
Maxima_viscosity_nc=max(Force_vis_nc_simulation);


Force_net_simulation_norm=Force_net_simulation/abs_Force_simulation_minima;
Force_appr_retr_simulation_norm=Force_appr_retr_simulation/abs_Force_simulation_minima;
Force_vis_c_simulation_norm=Force_vis_c_simulation/abs_Force_simulation_minima;
Force_vis_nc_simulation_norm=Force_vis_nc_simulation/abs_Force_simulation_minima;

figure (count_figures+15)

% plot(Data_sim((length(Data_sim(:,1))-20000):(length(Data_sim(:,1))), 2), Data_sim((length(Data_sim(:,1))-20000):(length(Data_sim(:,1))), 3), '.b','Markersize', 4, 'displayname','Force_net_simulation'); % Net
% hold on  
% plot(Data_sim((length(Data_sim(:,1))-20000):(length(Data_sim(:,1))), 2), Data_sim((length(Data_sim(:,1))-20000):(length(Data_sim(:,1))), 5), '.r', 'Markersize', 4, 'displayname','Force_appr_retr_simulation: No viscosity');   %% Approach retract 
% plot(Data_sim((length(Data_sim(:,1))-20000):(length(Data_sim(:,1))), 2), Data_sim((length(Data_sim(:,1))-20000):(length(Data_sim(:,1))), 6), '.k', 'Markersize', 4,'displayname','Force_vis_c_simulation');     %% Viscosity c
% plot(Data_sim((length(Data_sim(:,1))-20000):(length(Data_sim(:,1))), 2), Data_sim((length(Data_sim(:,1))-20000):(length(Data_sim(:,1))), 7), '.c', 'Markersize', 4,'displayname','Force_vis_nc_simulation');     %% Viscosity c

plot(Distance_simulation,Force_net_simulation_norm, '.b','Markersize', 4, 'displayname','Force_net_simulation'); % Net
hold on  
plot(Distance_simulation, Force_appr_retr_simulation_norm, '.r', 'Markersize', 4, 'displayname','Force_appr_retr_simulation: No viscosity');   %% Approach retract 
plot(Distance_simulation, Force_vis_c_simulation_norm, '.k', 'Markersize', 4,'displayname','Force_vis_c_simulation');     %% Viscosity c
plot(Distance_simulation, Force_vis_nc_simulation_norm, '.c', 'Markersize', 4,'displayname','Force_vis_nc_simulation');     %% Viscosity c


text(1e-9,1, ['F vis_n_c: ' num2str(Maxima_viscosity_nc), ' N'],'fontsize',12);
text(1e-9,0.6, ['F vis_c: ' num2str(Maxima_viscosity_contact), ' N'],'fontsize',12);
text(1e-9,0.2, ['F Adh. (Ap.Ret): ' num2str(Force_simulation_minima), ' N'],'fontsize',12);  %Maxima_viscosity_contact



axis([(min(Distance_simulation)-1e-9) 6e-9 -2 2])

title(' Force Fts versus distance d','fontsize',12)
xlabel('d','fontsize',14) 
ylabel('Force N','fontsize',14)

saveas(count_figures+15, num2str(15),'fig')	


figure (count_figures+11)
hold on
plot(Distance_simulation,Force_net_simulation, '-b','Markersize', 4, 'displayname','Force_net_simulation'); % Net
plot(Distance_simulation, Force_appr_retr_simulation, '.r', 'Markersize', 4, 'displayname','Force_appr_retr_simulation: No viscosity');   %% Approach retract 
plot(Distance_simulation, Force_vis_c_simulation, '.k', 'Markersize', 4,'displayname','Force_vis_c_simulation');     %% Viscosity c
plot(Distance_simulation, Force_vis_nc_simulation, '.c', 'Markersize', 4,'displayname','Force_vis_nc_simulation');     %% Viscosity c
saveas(count_figures+11, num2str(11),'fig')	

figure (count_figures+60)
hold on
plot(Distance_simulation,Force_net_simulation_norm, '-b','Markersize', 4, 'displayname','Force_net_simulation'); % Net
plot(Distance_simulation, Force_appr_retr_simulation_norm, '.r', 'Markersize', 4, 'displayname','Force_appr_retr_simulation: No viscosity');   %% Approach retract 
plot(Distance_simulation, Force_vis_c_simulation_norm, '.k', 'Markersize', 4,'displayname','Force_vis_c_simulation');     %% Viscosity c
plot(Distance_simulation, Force_vis_nc_simulation_norm, '.c', 'Markersize', 4,'displayname','Force_vis_nc_simulation');     %% Viscosity c

saveas(count_figures+60, num2str(60),'fig')	
