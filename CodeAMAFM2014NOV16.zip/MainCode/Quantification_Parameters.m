%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PARAMETRES TO CHOOSE IN QUNATIFICATION %%%%%%
% clear all;
% close all;
% load example2;

LIMITING_RANGE=1.6;		%%%  This number could go from 0 to 1.8 or 2 as limit. If close to two allows to check ranges in Fig. 71 that cover the whole range of curve 	
CONFIDENCE_INTERVAL_FIT= 0.02;			%%%% Confidence interval in non-linear fit is 2% for eta and surface energy 
Plot_process_quantification=1;
NonLinearFitting=1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Min_Amplitude_norm=min(A_norm);
Range_A_Total=A_norm(1)-A_norm(end);
Range_A_Total_crop=A_norm_crop(1)-A_norm_crop(end);

Range_A=1-A_norm;
Range_A_crop=1-A_norm_crop;


Amplitude_norm_d=(Range_A_Total-Range_A)/Range_A_Total;
Amplitude_norm_d_ss=smooth(Amplitude_norm_d,ss_amplitude_d,'rloess');

Amplitude_crop_norm_d=(Range_A_Total_crop-Range_A_crop)/Range_A_Total_crop;
Amplitude_crop_norm_d_ss=smooth(Amplitude_crop_norm_d,ss_amplitude_d,'rloess');

figure (count_figures+70)
hold on
box on

%%%%% Amplitude %%%%%
plot(D_M_ZEROED,Amplitude_norm_d, '.m', 'Markersize',M_size, 'displayname','Amplitud A/A0');    %%% 'fontsize',14,  ,  , 
plot(D_M_ZEROED_CROP,Amplitude_crop_norm_d, '.k', 'Markersize',M_size, 'displayname','Amplitud A/A0:crop');   
plot(D_M_ZEROED,Amplitude_norm_d_ss, '.g', 'Markersize',M_size, 'displayname','Amplitud A/A0: Smooth');    %%% 'fontsize',14,  ,  , 
plot(D_M_ZEROED_CROP,Amplitude_crop_norm_d_ss, '.c', 'Markersize',M_size, 'displayname','Amplitud A/A0:crop:Smooth');   

axis([(d_min(end)-1e-9) d_min(1) -1.2  1.2])
title(' Force, energy and amplitude','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Normalised force, energy and amplitude','fontsize',14)


%%%% Energy %%%%%%
plot(D_M_ZEROED, Edis_norm,'.m','Markersize',M_size, 'displayname','Energy Dissipated Normalised');   %% raw
plot(D_M_ZEROED_CROP, Edis_crop_norm,'.k','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped');  % raw

%%%% Smoothened %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
plot(D_M_ZEROED, Edis_norm_ss,'.g','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Smooth');  % smooth
plot(D_M_ZEROED_CROP, Edis_norm_crop_ss,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped:Smooth');  % smooth
%%%%%%
	
axis([ min_d_plot  max_d_plot -1.2 1.2])

if Sader_Katan==1
		
		hold on
		plot(d_min_crop_zeroed,Fts_S_K_cons_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		hold on
		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');

		axis([ min_d_plot  max_d_plot -1.2 1.2])	
		text(1e-9,0.8, ['Min Amplitude: ' num2str(Min_Amplitude_norm*A0*1e9), ' nm'],'fontsize',12);
		text(1e-9,0.6, ['A0 :' num2str(A0*1e9) '  nm'],'fontsize',12);
		text(1e-9,0.4, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
else
		
		text(1e-9,0.8, ['Min Amplitude: ' num2str(Min_Amplitude_norm*A0*1e9), ' nm'],'fontsize',12);
		text(1e-9,0.6, ['A0 :' num2str(A0*1e9) '  nm'],'fontsize',12);
		axis([ d_min(1) d_min(end)  0 1.2])
end



%%%%%%%%%%%%%%% Clean figure %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



figure (count_figures+71)
hold on
box on

%plot(D_M_ZEROED_CROP,Amplitude_crop_norm_d_ss, '.m', 'Markersize',M_size, 'displayname','Amplitud A/A0:crop:Smooth');   
plot(D_M_ZEROED, Edis_norm_ss,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped:Smooth');  % smooth


if Sader_Katan==1
		
		hold on
		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');
		axis([ min_d_plot  max_d_plot -1.2 1.2])	
		text(1e-9,0.8, ['Min Amplitude: ' num2str(Min_Amplitude_norm*A0*1e9), ' nm'],'fontsize',12);
		text(1e-9,0.6, ['A0 :' num2str(A0*1e9) '  nm'],'fontsize',12);
		text(1e-9,0.4, ['Max Edis: ' num2str(Edis_max_T), ' eV'],'fontsize',12)
		text(1e-9,0.2, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
else
		
		text(1e-9,0.8, ['Min Amplitude: ' num2str(Min_Amplitude_norm*A0*1e9), ' nm'],'fontsize',12);
		text(1e-9,0.6, ['A0 :' num2str(A0*1e9) '  nm'],'fontsize',12);
		axis([ d_min(1) d_min(end)  0 1.2])
end
title(' Pick range Indentation for Energy FIT','fontsize',12)


%% pick points to crop %%%%%%

[q1,q2]=ginput(2);

Pck_q=[q1 , q2];
Pck_q=sort(Pck_q,1); 


%%%%%%%%%%%%%%%%%%%%%    Find points %%%%%%%%%%%%%%
for ii=1:1:2
            
		d_values_q(ii,1)=Pck_q(ii,1); 
		Minimum_pick_q(ii,1)=Pck_q(ii,2);
        plot(d_values_q(ii,1),  Minimum_pick_q(ii,1),'Vk', 'Linewidth', 2, 'Markersize',6);
		
		
		if ii==1
	    DD_LIMITED=D_M_ZEROED(LIMITING_RANGE*floor(length(D_M_ZEROED))/2:end);
        Minimum_error_dumb_q=MultiplierError*min(abs(DD_LIMITED-d_values_q(ii,1)));
        Minimum_error_q(ii,1)=Minimum_error_dumb_q;
        Position_d_dumb_q=find(abs(DD_LIMITED-d_values_q(ii,1))<=abs(Minimum_error_dumb_q),1, 'first');
		lll_1=length(D_M_ZEROED);
		lll_2=length(DD_LIMITED);
		Position_d_dumb_q=Position_d_dumb_q+(lll_1-lll_2);
		end
		
		if ii==2
		Minimum_error_dumb_q=MultiplierError*min(abs(D_M_ZEROED-d_values_q(ii,1)));
        Minimum_error_q(ii,1)=Minimum_error_dumb_q;
        Position_d_dumb_q=find(abs(D_M_ZEROED-d_values_q(ii,1))<=abs(Minimum_error_dumb_q),1, 'first');
	
		end
		
        Position_q(ii,1)=Position_d_dumb_q; % this is the position of the vector element
        Energy_found_q(ii,1)=Edis_norm(Position_d_dumb_q);
		d_found_q(ii,1)=D_M_ZEROED(Position_d_dumb_q);
        plot(d_found_q(ii,1),  Edis_norm_ss(Position_d_dumb_q),'Vk','Linewidth', 4, 'Markersize',6)
                             
end  


%%%%%%% Prepare vectors to calculate K %%%%%%%%%%%%%%%%%%%%

Q_Energy=Edis_norm_ss(Position_q(2,1):Position_q(1,1));
Q_Indentation=D_M_ZEROED(Position_q(2,1):Position_q(1,1));
Q_Amplitude=A_norm(Position_q(2,1):Position_q(1,1));

%%%% Standard  International Units %%%%%%

Q_Energy_IU=Q_Energy*Edis_max_T/6.24e18;  %%% This is Joules
Q_Energy_IU_q=Q_Energy_IU-Q_Energy_IU(1);
Q_Indentation_IU_q=abs(Q_Indentation-(Q_Indentation(1)-0.0001e-9));
Q_Amplitude_IU_q=Q_Amplitude*A0;

K_vector_nominator=(Q_Energy_IU_q(1:end-1)./Q_Indentation_IU_q(1:end-1))-(Q_Energy_IU_q(2:end)./Q_Indentation_IU_q(2:end));
K_vector_denominator=((Q_Amplitude_IU_q(1:end-1)).^(0.5).*Q_Indentation_IU_q(1:end-1))-((Q_Amplitude_IU_q(2:end)).^(0.5).*Q_Indentation_IU_q(2:end));

K_vector=K_vector_nominator./K_vector_denominator;



%%%% REMOVE NANS ETC %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%  curve raw %%%%
	DUMMY_YY=zeros(length(K_vector));
	DUMMY_XX=zeros(length(Q_Indentation_IU_q(1:end-1)));
	DUMMY_YY=K_vector;
	DUMMY_XX=Q_Indentation_IU_q(1:end-1);

	GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
	K_real=DUMMY_YY_real;
	d_q_real=DUMMY_XX_real;
	
K_vector_abs=abs(K_real)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Get rid of outliers for K %%%%%%%%%%%%%

Data_input=abs(K_vector_abs);

Chauvenete;
Outliers_K_vector=c19;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ETA AND Delta Gamma %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K_vector_abs_mean=mean(K_vector_abs)
K_vector_abs_std=std(K_vector_abs)
Eta_constant=2*sqrt(2)/pi/(R^(0.5))/(2*pi*f0)*K_vector_abs_mean


Chauvenete_K_vector_mean=mean(Data_input)
Chauvenete_K_vector_std=std(Data_input)


%%%%%%% Calculate eta %%%%%%%%%%%%%%%%%%%%%%%%%

Constant_eta=2*sqrt(2)/pi/(R^(0.5))/(2*pi*f0);


Eta_constant_Chauvenete=Constant_eta*Chauvenete_K_vector_mean
Eta_constant_Chauvenete_std=Constant_eta*Chauvenete_K_vector_std

%%%%%%% Calculate delta gamma %%%%%%%%%%%%%%%%%%%%%%%%%
Constant_delta_gamma=1/4/pi/R;

Delta_gamma_raw=Constant_delta_gamma*((Q_Energy_IU_q./Q_Indentation_IU_q)-((Q_Amplitude_IU_q.^(0.5)).*Q_Indentation_IU_q*Chauvenete_K_vector_mean))
Delta_gamma_raw_abs=abs(Delta_gamma_raw);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Get rid of outliers for delta gamm %%%%%%%%%%%%%

Data_input=Delta_gamma_raw_abs;

Chauvenete;
Outliers_delta_gamma=c19;
%%%%%%%%%%%%%%%%%
Delta_gamma_raw_abs_mean=mean(Delta_gamma_raw_abs)
Delta_gamma_raw_abs_std=std(Delta_gamma_raw_abs)

Chauvenete_Delta_gamma_mean=mean(Data_input)
Chauvenete_Delta_gamma_std=std(Data_input)

figure (count_figures+71)   %%%% Plot analytical fitting 
hold on
% plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');
axis([ min_d_plot  max_d_plot -1.2 1.2])	
text(1e-9,-0.8, ['eta: ' num2str(Eta_constant_Chauvenete), ' Pa s'],'fontsize',12);
text(1e-9,-0.6, ['Delta Gamma: ' num2str(Chauvenete_Delta_gamma_mean) '  mJ/m2'],'fontsize',12);
text(1e-9,-0.4, ['eta (std): ' num2str(Eta_constant_Chauvenete_std), ' Pa s'],'fontsize',12)
text(1e-9,-0.2, ['Delta Gamma (std): ' num2str(Chauvenete_Delta_gamma_std), ' mJ/m2 '],'fontsize',12)

xlabel('dmin','fontsize',14) 
ylabel('Normalised energy ANALYTIC: FIT','fontsize',14)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Energies  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Constant_eta_2=sqrt(2)/4*pi*(R^(0.5))*(2*pi*f0);
Constant_delta_gamma_2=4*pi*R;

Q_Energy_eta_IU_q=Constant_eta_2*Eta_constant_Chauvenete*(Q_Amplitude_IU_q.^(0.5)).*(Q_Indentation_IU_q.^2)
Q_Energy_delta_gamma_IU_q=Constant_delta_gamma_2*Chauvenete_Delta_gamma_mean.*Q_Indentation_IU_q

distance_q_r=-(Q_Indentation_IU_q-(Q_Indentation(1)-0.0001e-9));

Normalized_energy_eta=Q_Energy_eta_IU_q*6.24e18/Edis_max_T;
Normalized_energy_delta_gamma=Q_Energy_delta_gamma_IU_q*6.24e18/Edis_max_T;

Substract_norm_Energy=Q_Energy_IU(1)*6.24e18/Edis_max_T;
figure (count_figures+71)   %%% PLot the fitting of the analytical fit
hold on
box on
Energy_total_fit_norm=Normalized_energy_eta+Normalized_energy_delta_gamma;
Energy_true_norm=Edis_norm_ss-Substract_norm_Energy;

plot(distance_q_r, Normalized_energy_eta, '.r','Markersize',M_size, 'displayname','Energy Dissipated viscoelasticity');
plot(distance_q_r, Normalized_energy_delta_gamma, '.m','Markersize',M_size, 'displayname','Energy Dissipated surface energy');
plot(distance_q_r, Energy_total_fit_norm, '.k','Markersize',M_size, 'displayname','Energy Dissipated Total fit');
%%%% Plot Total true fitted energy %%%%%
plot(D_M_ZEROED, Energy_true_norm,'.c','Markersize',M_size, 'displayname','Energy to FIT Normalised:Smooth');  % smooth


%%%%%%%%%%%  Calculating error Energy fit %%%%%%%%%
Energy_true_norm=Q_Energy_IU_q*6.24e18/Edis_max_T;
Differemce_squared_energy_fit=(((Energy_true_norm(2:end)-Energy_total_fit_norm(2:end))/max(abs(Energy_true_norm))).^2);


Data_input=Differemce_squared_energy_fit;

Chauvenete;
Sum_squared_energy_fit=sum(Data_input);
energy_fit_points=length(Data_input);

Standard_deviation_error_energy_fit=floor(sqrt(1/energy_fit_points*(Sum_squared_energy_fit))*100);

text(1e-9,-1, ['ERROR FIT (STD): ' num2str(Standard_deviation_error_energy_fit), ' %'],'fontsize',15);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure (count_figures+72)
hold on
box on 
plot(Q_Amplitude_IU_q/A0, Normalized_energy_eta, '.r','Markersize',M_size, 'displayname','Energy Dissipated viscoelasticity');
plot(Q_Amplitude_IU_q/A0, Normalized_energy_delta_gamma, '.m','Markersize',M_size, 'displayname','Energy Dissipated surface energy');
plot(Q_Amplitude_IU_q/A0, Normalized_energy_eta+Normalized_energy_delta_gamma, '.k','Markersize',M_size, 'displayname','Energy Dissipated Total fit');
%%%% Plot Total true fitted energy %%%%%
plot(A_norm, Edis_norm_ss-Substract_norm_Energy,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised:REPULSIVE: Smooth');  % smoo
plot(A_norm, Edis_norm_ss,'.b','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Smooth');  % smoo

title(' Energy ANALYTIC: FIT','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Normalised  energy ANALYTIC: FIT','fontsize',14)

text(0.5,0.2, ['eta: ' num2str(Eta_constant_Chauvenete), ' Pa s'],'fontsize',12);
text(0.5,0.4, ['Delta Gamma: ' num2str(Chauvenete_Delta_gamma_mean) '  mJ/m2'],'fontsize',12);
text(0.5,0.6, ['eta (std): ' num2str(Eta_constant_Chauvenete_std), ' Pa s'],'fontsize',12)
text(0.5,0.8, ['Delta Gamma (std): ' num2str(Chauvenete_Delta_gamma_std), ' mJ/m2 '],'fontsize',12)
text(0.7,1, ['ERROR FIT (STD): ' num2str(Standard_deviation_error_energy_fit), ' %'],'fontsize',15);

%%%% Non linear Fitting %%%%%%%%%%%%%%%%%
%%% http://www.nbb.cornell.edu/neurobio/land/projects/MKG23curvefit/index.html

if NonLinearFitting==1
	NonLinearFitting_dissipation_2Parameters;
end






