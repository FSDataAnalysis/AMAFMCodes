% Nonlinear parameter estimation and errors from Matlab.
% Introduction 
% 
% We needed to estimate a set of parameters and their errors for a nonlinear curve fit of cellular conductance data. The conductance was a function of voltage and was modeled as a Boltzmann term, an exponential term and a constant:: 
% 
% g = p3/(1+e((v-p1)/p2)) + p5*e((v-45)/p6) + p4 
% 
% Where g and v are the input data, with v is in millivolts, and p1-p6 are the desired parameters. 
% 
% A program was produced to: 
% 
% Fit data several times with randomly selected starting conditions to validate the fit and make sure the code was not falling into local minima. 
% Plot all of the curve fits and separate out the Boltmann and exponential terms. 
% Estimate the errors in the parameters as the greater of the multiple fit scatter and the formal propagated error. 
% List the parameters and a table of the Boltzmann and exponential term conductances. 
% The program 

%Program for Matt Gruhn
%Written by Bruce Land, BRL4@cornell.edu
%May 20, 2004
%===================
%curve fit of 6 parameter conductance function of voltage
%Formula from Matt:
%g=	(m3/((1+exp((m0-m1)/m2))^(1)))+(m4)+(m5*exp((m0-45)/m6)); 
%need to get parameters and their error range
%--Then separately plot the "boltzmann" and exponential parts separately
%===================

% clear all
% %total fit
% figure(1)
% clf
% %part fit
% figure(2)
% clf
% %parameter histograms
% figure(3)
% clf

%========================================================
%START settable inputs
%========================================================
%data set 1 from Matt-- cell f 
%the voltages
% x=[-30.3896
%     -25.2314
%     -20.0655
%     -14.9218
%     -9.82205
%     -4.71594
%     0.380856
%     5.53925
%     10.749
%     15.8878
%     21.0423
%     26.154
%     31.3026
%     36.3964
%     41.4244
%     46.3951
% ];

%the measured conductances
% y=[0.01428535
%     0.032721504
%     0.06306213
%     0.099658404
%     0.134567811
%     0.162306115
%     0.181366575
%     0.196532089
%     0.20765796
%     0.218294045
%     0.22529785
%     0.235617098
%     0.250215255
%     0.268659046
%     0.294750456
%     0.331398216
% ];

%estimate of error in conductance measurement
%Currently set to 2%
% clear all;
% close all;
% load example2;
% Plot_process_quantification=1;

%%%%%%
y=Q_Energy_IU_q;
dy = y*CONFIDENCE_INTERVAL_FIT;

x=[Constant_eta_2*((Q_Amplitude_IU_q.^(0.5)).*(Q_Indentation_IU_q.^2)) Constant_delta_gamma_2*Q_Indentation_IU_q]; 
	
%formula converted to
%The inline version
func = inline('p(1)*x(:,1)+p(2)*x(:,2)','p','x')

%initial parameter guess
p0 = [Eta_constant_Chauvenete Chauvenete_Delta_gamma_mean];

%To detect the sensitivity of the fit to starting parameter guess,
%the fit is run a number of times.
%each fit is plotted and each parameter plotted as a histogram
Nrepeat=20;
%each parameter is varied by a normal distribution with
%mean equal to the starting guess and std.dev. equal to
%sd*mean
sd = 0.3;
%histogram zoom factor (how many std dev to show)
zfactor = 2;
%parameter outlier cuttoff: lowest and highest N estimates are removed
outcut=10;
%========================================================
%END settable inputs
%========================================================
terms=2;
%list of all parameter outputs to use in histogram
pList=zeros(Nrepeat,terms);

for rep =1:Nrepeat
    %     rep
    
    %form the new randomized start vector
    p = [p0(1)*(1+sd*randn), p0(2)*(1+sd*randn)];
    %do the fit
    [p,r,j] = nlinfit(x,y,func,p);
    %copy fit to list
    pList(rep,:) = p';
    
    %get parameter errors
    c95 = nlparci(p,r,j);
    [yp, ci] = nlpredci(func,x,p,r,j);
    
    %plot the fit
	if Plot_process_quantification==1 
		figure (count_figures+73)
		hold on 
		box on
		title(' Energy NONLINEAR: FIT','fontsize',12)
		xlabel('A/A0','fontsize',14) 
		ylabel('Normalised  energy NONLINEAR: FIT','fontsize',14)
	
		errorbar(Q_Amplitude_IU_q,func(p,x)*6.24e18,ci,ci,'b-');

		hold on

		errorbar(Q_Amplitude_IU_q,y*6.24e18,dy,dy,'ro');
		
	end
end

output=mean(pList);
output_std=std(pList);


if (((output(2)>0)&&(output(1)>0))||(Plot_process_quantification==1))  %%%% if everything is positive plot or if plot these processing steps even if negative
			
	%%%%%% Print fit of energies 2 fit %%%%%%%%

	figure (count_figures+74)
	hold on
	box on
	title(' STATS NONLINEAR : FIT','fontsize',12)
	% %plot and print parameter table
	fprintf('\r\rFit parameters and 95percent confidence range\r')
	title(' Viscosity and Surface Energy Hysteresis NONLINEAR FIT','fontsize',12)
	for i=1:terms
		subplot(terms,1,i)
		lowerLimit = mean(pList(:,i))-zfactor*std(pList(:,i));
		upperLimit = mean(pList(:,i))+zfactor*std(pList(:,i));
		hist(pList(:,i),linspace(lowerLimit,upperLimit,30))
		Limits(i,1)=lowerLimit
		Limits(i,2)=upperLimit
		%
		fprintf('%7.3f\t +/- %7.3f \r',...
			mean(pList(:,i)),...
			max(2*std(pList(:,i)),mean(pList(:,i))-c95(i,1)));
	
		subplot(2,1,1)
		hold on
		box on
		xlabel('Pa s ','fontsize',14) 
		ylabel('Counts','fontsize',14)  
	
		subplot(2,1,2)
		hold on
		box on
		xlabel('mJ/m2 ','fontsize',14) 
		ylabel('Counts','fontsize',14) 
	
	
	end

	fprintf('\r\rFit parameters omitting outliers\r')
	for i=1:terms
		%get rid of outliers
		pup = sort(pList(:,i));
		pup = pup(outcut:end-outcut);
		%print again
		fprintf('%7.3f\t +/- %7.3f \r',...
			mean(pup),...
			max(2*std(pup),mean(pup)-c95(i,1)));
		pbest(i)=mean(pup);
	end
	
	%%%%%%%%%%%%%%%%%%%%%%% PLOT Energies %%%%%%%%%%%%%%%%%%%%%
	omg=2*pi*f0;
	Energy_surface_nl = Constant_delta_gamma_2*output(2).*Q_Indentation_IU_q;
	Energy_eta_nl = Constant_eta_2*output(1)*((Q_Amplitude_IU_q.^(0.5)).*(Q_Indentation_IU_q.^2));
	Energy_nl_total=Energy_surface_nl+Energy_eta_nl;
	
	Energy_nl_total_norm=Energy_nl_total*6.24e18/Edis_max_T;
	%Substract_norm_Energy=Q_Energy_IU(1)*6.24e18/Edis_max_T;
	
	Energy_surface_nl_norm=Energy_surface_nl*6.24e18/Edis_max_T;
	Energy_eta_nl_norm=Energy_eta_nl*6.24e18/Edis_max_T;

	figure (count_figures+75)
	hold on
	box on
	plot(Q_Amplitude_IU_q/A0, Energy_eta_nl_norm, '.r','Markersize',M_size, 'displayname','Energy Dissipated viscoelasticity');
	plot(Q_Amplitude_IU_q/A0,Energy_surface_nl_norm , '.m','Markersize',M_size, 'displayname','Energy Dissipated surface energy');
	plot(Q_Amplitude_IU_q/A0, Energy_nl_total_norm , '.k','Markersize',M_size, 'displayname','Energy Dissipated Total fit');
	%%%% Plot Total true fitted energy %%%%%
	plot(A_norm, Edis_norm_ss-Substract_norm_Energy,'.c','Markersize',M_size, 'displayname','Energy to FIT Normalised:REPULSIVE: Smooth');  % smoo
	plot(A_norm, Edis_norm_ss,'.b','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Smooth');  % smoo

	title(' Energy NONLINEAR: FIT','fontsize',12)
	xlabel('A/A0','fontsize',14) 
	ylabel('Normalised  energy ANALYTIC: FIT','fontsize',14)
	
	text(0.5,0.2, ['eta: ' num2str(output(1)), ' Pa s'],'fontsize',12);
	text(0.5,0.4, ['Delta Gamma: ' num2str(output(2)) '  mJ/m2'],'fontsize',12);
	text(0.5,0.6, ['eta (std): ' num2str(output_std(1)), ' Pa s'],'fontsize',12)
	text(0.5,0.8, ['Delta Gamma (std): ' num2str(output_std(2)), ' mJ/m2 '],'fontsize',12)
	
	axis([ min(A_norm)  1 0 1.4])	
	%%%%%%%%%%%  Calculating error Energy fit %%%%%%%%%
% 	Energy_true_norm=Q_Energy_IU_q*6.24e18/Edis_max_T;
	Differemce_squared_energy_nl_fit=(((Energy_true_norm(2:end)-Energy_nl_total_norm(2:end))/max(abs(Energy_true_norm))).^2);


	Data_input=Differemce_squared_energy_nl_fit;

	Chauvenete;
	Sum_squared_energy_nl_fit=sum(Data_input);
	energy_nl_fit_points=length(Data_input);

	Standard_deviation_error_energy_nl_fit=floor(sqrt(1/energy_nl_fit_points*(Sum_squared_energy_nl_fit))*100);

	text(min(A_norm),1.1, ['ERROR NL FIT (STD): ' num2str(Standard_deviation_error_energy_nl_fit), ' %'],'fontsize',15);
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	for iii=74:75    %%%% 
		saveas(count_figures+iii, num2str(iii),'fig')	
	end

	
	
end  

if  ~((output(2)>0)&&(output(1)>0)) %%% something negative 
	
	
	if ((output(1)<0)&&(output(2)>0))
	  %%% Surface energy hysteresis only since viscosity is negative 
		CCC_1=Constant_delta_gamma_2*Q_Indentation_IU_q;	
		%initial parameter guess
		p0 = [Chauvenete_Delta_gamma_mean]; 
		NonLinearFitting_dissipation;
	end
	if ((output(2)<0)&&(output(1)>0)) %%%%  viscosity positive, surface energy negative 
		CCC_1=Constant_eta_2*((Q_Amplitude_IU_q.^(0.5)).*(Q_Indentation_IU_q.^2));
		%initial parameter guess
		p0 = [Eta_constant_Chauvenete]; 
		NonLinearFitting_dissipation;
	end
	if ((output(2)<0)&&(output(1)<0))	
		figure (count_figures+75)
		hold on
		box on
		text(0.5,0.9, ['RESULTS: ALL NEGATIVE NL FIT: A0' num2str(A0*1e9), 'nm'],'fontsize',12);
		axis([ 0  1 0 1.4])
		saveas(count_figures+75, num2str(75),'fig')	
		%all negative 	
	else
		figure (count_figures+75)
		hold on
		box on
		text(0.1,0.9, ['RESULTS: AT LEAST ONE NEGATIVE NL FIT: A0 ' num2str(A0*1e9), 'nm'],'fontsize',14);	
		axis([ 0  1 0 1.4])
		saveas(count_figures+75, num2str(75),'fig')	
		
	end
end

if Plot_process_quantification==1 

	for iii=73:75    %%%% Beware of Plot_process_quantification being 1 in Quantification Parameters file. If so then 70-78.. 73-78 is a nonlinear fit
				saveas(count_figures+iii, num2str(iii),'fig')	
	end

end

%%%%%% If it doesnt enter any of the above everything is positive %%% Thn 





