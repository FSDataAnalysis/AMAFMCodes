% clear all;
% close all;
% load foo;
% clc
tic


originaldir=pwd;
mkdir('MAT_DATA');

format shortEng

%The following code should be used for an automated process
% Select the folder containing all of the .txt files in the order you would
% like them to be analyzed- no subfolders!!
% fPath = uigetdir('.', 'Select directory containing the files');
% if fPath==0, error('no folder selected'), end
% fNames = dir(fullfile(fPath,'*.txt') );
% fNames = strcat(fPath, filesep, {fNames.name});
count_trials=0;


% prompt= {'Spring Constant:','ThermalQ:','Frequency:','Crop at:','Smoothing Coefficient:','Elastic Modulus? 1 or 0:', ...
%     'InVolts:', 'Tip Radius: ', 'remove_start:', 'remove_end:', 'subtract end YM:', 'subtract start YM:'};
% 
% 
% dlg_title='Inputs';
% num_lines=1;
% default={'','','','2','0.03','1', '40', '7e-9', '100', '50', '40', '20'};
% answer=inputdlg(prompt,dlg_title,num_lines,default);

%%%% counter added for elasticity stuff S Santos 2014, Sept ####
counter_m=1;

counter_files_done=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% counter added for  stuff S Santos 2014, Oct ####
counter_analytical_stuff=1;
save_numerical_values=1; %% if 0 it doenst not calculate 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Virial_plot=1;  %% The Virial need to be 1 in order to use save_numerical_values

%%%%%%% Data on outliers/or start and end of vectors %%%%%%%%%%%%%%%%%%%%%%

remove_start= str2double(answer(9));
remove_end= str2double(answer(10));
subtract_EModulus= str2double(answer(10));
add_EModulus= str2double(answer(12));



% Cycle through each file individually
for i=1:length(fNames)
    DtAq=load(fNames{i});
%This part of the code makes a new folder for every text file. In this
%version of the code, every time the program saves, it changes its
%directory to that of the new folder, and then changes it back after the
%save
    [pathstr, name, ext]=fileparts(fNames{i});
    foldname=name;
    cd(fPath);
    mkdir(foldname);
    cd(originaldir);
  
%The following code can be used for manual processing of a single file at a
%time
%[filename, pathname,filterindex] = uigetfile({'*.txt'},'File Selector');
%if isequal(filename,0)
%return
%elseif isequal(filterindex,1)
%    DtAq=load ([pathname,'\',filename]);
%end

% ====================================================================================================================================================
% ===================== USER settings =========================================================================================================
% ====================================================================================================================================================


% k=42;                           % N/m
% Q=450;                          % Quality factor
% R = 8e-9;                       % tip radius [m]
% f0=305e3;

k= str2double(answer(1));						%%                      40 Sim    % N/m
Q= str2double(answer(2));							%%% sim 450;                          % Quality factor
R =  str2double(answer(8));                      % tip radius [m]
f0= str2double(answer(3));					% Graphite   304.192e3;					%%% mica 318.167e3;					% Sim 300e3; 304192
AmpInvOLS =  str2double(answer(7));	%% gr 	60% RH 42%   %% Mica 10%RH 37.5; Mica 60% 40.2   % 80% RH 40.4   (mica Carlo 39-39.5) 36.8;% (Silicon) %42.5;   %% 36.8 nm/V for Silicon    %% nm/V; Useless if Pick_Amps = 1  For silicon Model some 37nm/volt required   41.5 for mica and 36.5 for the work
%%
M_size=5;						% Marker size. 6 for FFT simulation 3 for continuous
set(0,'DefaultAxesFontSize',14)  %%% This sets the font size in figures
set(0,'DefaultAxesFontSize',14)  %% axis size figures
set(0,'DefaultAxesLinewidth',2)  %% Lne width figures
box on

count_trials=count_trials+1;
%mkdir(num2str(count_trials));

Extension=1;                            % If 1 then it does extension otherwise with 0  retraction curve (experimental only) 
Smooth_raw_data=1;						%%% Smoothens the raw data. Requied 1 for experimental only  This slows down. Also requires to rearrange dmin from larger to smaller. 
Smooth_OMEGA=1;							%%% Smoothens omega and omega difference
Averaging_percentage_of_signal=0.02;    %% This is the percentage of avergaing for setting phase at 90, deflection at zero, etc. DEFAULT 0.1 
crop_initial_data=0;					%%% Allows you to crop both ends of initial data 
Limit_AmplitudeToA0=1;					%%% This limits amplitudes to A0, so there are no complex numbers for zc>>A0 due to thermal noise
Maximum_lenght_data_set=0;				%% If 1 it will chop data to the number especified below 
Maximum_lenght_data=5000;				% If a number is chosen the length of the vectors wil be between that and double that if 1 is chosen above 
use_real_Edis=0;						%%% If 1 it uses real Edis. Only valid for simualtion, otherwise zero. This only affects the analytical file 
FFT_Data=0;								%%% If FFT Data (typically simulation)  just leave to 1. If zero, it trims from the continuous curves on both sides 100
plot_data_processing_figures=0;			%%% If zero you do not see how the data is being prepared to be processed. Figs. 1-2 4-10 not shown and extra analysis 
plot_raw_curves=0;						% If 1 it plots raw curves, deflection, amplitude and phase 
save_files_processing=0;				%%% This saves plotted figures 1-10 in the begining				
save_files_further_analysis=1;			%%   These are energy dissipation, phase difference, etc. 
save_extra_analysis=0;					%%%%  derivatives, Viraial etc
save_quantification=0;
save_files_Sader_Katan=0;				%% Figures 11 and 12 forces and damping
save_files_Raman=0;

%%%%% Simulation data or experimental data  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Simulation=0;							%% If simulation=1 then the data is simulation, if 0 then experimental
Load_simulation_forces=0;				%% This loads simulation forces at the end if activated. Simulation also has to be active. 
eta_c=0;								%% This is for viscoelastic models but it is deactivated now
a0=0.165e-9;							%% This is for viscoelastic models but it is deactivated now

%%%%%%%%% Solution Method %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Raman's solution parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Sader_Katan=1;						%%% Solves by Katan and Sader method
Raman=0;							%%% Solves by Raman method 
Further_Analysis=1;					%%% This gets analytical stuff like virial and energy dissipation
Quantification=0;					%%%% Quantifies dissipative coefficients etc.
Calculate_elastic_modulus=str2double(answer(6));		%%% Fits elastic modulus 


omg_f0 = 2*pi*f0 ;                  % Angular frequency  natural Omega [rad/s]
omg_drive=omg_f0;

gamma_medium=k/omg_f0/Q;
                                      
			
%%%% More details  ==========================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Sorting_zc_larger_to_smaller=0;         % DEFAULT 0. If 1, then it forces zc to always decrease, i.e. drift removal, if 0, it does not do it, i.e. drift present, complex numbers might result. 
Removing_repeat_zc=0;                   % Default 0. IMPORTANT. Sorting Zc required for this to work. Otherwise it removes many points. if 1 then it removes repeated zc.
Virial_Distances=1;						%%% Finds distances in virial
Percentage_Virial=0.08;					%%% This is where we want to start counting virial for figure 60
Attractive_Distances=1;					%% activates looking at distances of attractive forces figure 11
Attractive_min_force=0.2e-9;			%%% From the above, checks minimum force here to zero. figure 11
Damping_magnitude=0.1e-9;				%%% If Attractive_Distances activated then it checks at which distance (relative to zero) the damping starts to be larger than chosen  value
Error_Attractive_zero=0.15e-9;			%% This is the error to locate minimum in force
Bistable_curves=0;                      % If the curve shows bistability, then 1, otherwise with continuous transition 0 NOT DONE YET

%%%%%==================================================================================================================================== %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%% Experimental loading detail ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%									  
% Columns order: 2 Zs [m], 2 Amplitudes [V], 2 Phases [o] and 2 Delfs [V]
%(each has extend and retracrt) 

%%% Carlo December data %%%
%ZEx =1 ; DfEx =3; ZRet = 4;  DfRet = 6; AEx =7 ;  ARet =8 ; PEx =9 ;  PRet =10;

%%%% standard %%%%
ZEx =1 ; DfEx =2 ; ZRet = 3;  DfRet = 4; AEx =5 ;  ARet =6 ; PEx =7 ;  PRet =8 ;

%%%%%%%%%%%%%%%% END Experimental
%%%%%%%%%%%%%%%% loading====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%% Simulation loading detail ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%

if Simulation==1 % Simulation data load
	%%%% SimZc=1;  SimAm=2; SimPh=3; SimDf=4; SimApeak=5;  SimPhpeak=6;	%% This is how the data is in the original simulation file	
	ZEx=1;  AEx=2; PEx=3;  DfEx=4; E_T=5;
	rrr=5;    % number of column vectors in file  %% Typically 20 for nomrmal files. Short files 8. FFT ZZc, Amp Phase Def Energy is 5
end



%%%%%%%%%%%%%%%% Simulation loading detail ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%% END loading details ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%========= Smoothening coefficients    ==============================================================================================%%%%

  %%% Stuf with single s implies smoothening data to be processed. Double ss is for the smoothening that accurs after processing all raw data

  ss_Fts_cons_S_K=str2double(answer(5));   %% This is Katan Sader conservative. Smoothens the final coefficient. This works fine and should be enabled for experimental data (also used in simulation)
  ss_Damping_Coeff=0.015;  %% Smoothens the final coefficient. This works fine and should be enabled for experimental data
  s_defl=0.1;
  s_d_min=0.01;
  s_d_min_Incr=0.01;    %%% smooth dmin incre when dmin is not previously smoothened
  s_Omega_AM=0.003;
  s_Omega_Incr=0.001;
  s_F_dis=0.01;
  s_Fts_cons_s=0.015;       %% Smoothens the final conservative with rloess
  s_Fts_dis_s=0.04;
  s_Virial=0.04;
  %%% Only simulation below %%%%
  s_Edis=0.01;				%%% Typically for simulation of very smooth experimental data 
  Derivative_points_sim=1;  %%% Points to calculate derivative of energy 		
  s_Damping_Coeff=0.008;
  s_Derivative=0.08;
  s_Derivative_A=0.1;
  s_Derivative_A_A=0.08;
  s_Derivative_Edis=0.1;

 MultiplierError=1;  
% ====================================================================================================================================================
% ===================== end of user settings =========================================================================================================
% ====================================================================================================================================================


%%

count_figures=0;


if Simulation==0 % Experimental data load
	rrr=8;    % Standard 
end


length_vectors=size(DtAq,2);

for ccc=1:rrr:length_vectors
	
        if Simulation==0					% Experimental data load------------------------------------------------------------------------------

            set_d=DtAq(:,ccc:ccc+rrr-1);
        end

        if Simulation==1

            Extension=1;					% Simulation data load. Always extension only ------------------------------------------------------
            set_d=DtAq(:,ccc:ccc+rrr-1);

        end

        Pre_processing_raw_data;

        if Simulation==0    % i.e. experimental 
            ZsnrEx =ZsnrEx-ZsnrEx(end);   %% last zc is zero 
        end

        %%%%%%%%%%%%%% PLOT amplitude, deflection and phase %%%%%%%%%%%%%%%%%%%%%%%%%%
        %close (count_figures+1)
        if plot_data_processing_figures==1
            figure (count_figures+1)
            plot(ZsnrEx,AmEx, '.k', 'Markersize',M_size, 'displayname','Amplitud A');    %%% 'fontsize',14,  ,  , 

            hold on
            title(' Amplitude and deflection versus zc','fontsize',12)
            xlabel('Zc','fontsize',14) 
            ylabel('Amplitude','fontsize',14)

            plot(ZsnrEx,DflEx, '.c', 'Markersize',M_size,'displayname','Amplitud A');

        end

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Calculate parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



        %%%%%%%%%%%%% Conservative branch %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        A0 = mean(AmEx(1:floor(0.02*length(AmEx))));
        AmEx_dummy=AmEx;
        ANGLE_CONSERVATIVE=zeros(length(PhEx),1);
        trial=zeros(length(PhEx),1);
        for iii=1:length(PhEx)

            if AmEx_dummy(iii, 1)>A0    %% fluctuations in A0 are due to thermal noise
                AmEx_dummy(iii, 1)=A0;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LIMITING MAXIMUM AMPLITUDES TO A0 GETS RID OF COMPLEX %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if Limit_AmplitudeToA0==1
                    AmEx(iii,1)=A0;
                end	
            end
        end	

        for iii=1:length(PhEx)
            trial(iii,1)=asin(AmEx_dummy(iii, 1)/A0);
            ANGLE_CONSERVATIVE(iii, 1)=trial(iii, 1)*180/pi;
            if PhEx(iii,1)>90
                ANGLE_CONSERVATIVE(iii, 1)=180-ANGLE_CONSERVATIVE(iii, 1);
            end
        end


      %%%%%%%%%%% Phase in zc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if plot_data_processing_figures==1
            figure (count_figures+2)
            plot(ZsnrEx,PhEx, '.r', 'Markersize',M_size, 'displayname','Phase degrees');
            box on
            hold on
            plot(ZsnrEx,ANGLE_CONSERVATIVE, '.b', 'Markersize',M_size, 'displayname','Phase Conservative');
            title(' Phase versus zc','fontsize',12)
            xlabel('Zc','fontsize',14) 
            ylabel('Phase','fontsize',14)
        end

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Calculate parameters II %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



            d_min=ZsnrEx-AmEx;     %%%%%%%  d_min defined raw ====================================
            d_min_Smth= smooth(d_min,s_d_min,'rloess');
            d_min_Incr=d_min(2:end)-d_min(1:end-1);
            d_min_Incr_Smth= smooth(d_min_Incr,s_d_min_Incr,'rloess');

            %%% plot dmin  ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            figure(count_figures+3)
            hold on
            plot(ZsnrEx, d_min, '.r','Markersize',M_size, 'displayname','Dmin');
            hold on
            box on
            title(' Dmin versus zc','fontsize',12)
            xlabel('Zc','fontsize',14) 
            ylabel('Dmin','fontsize',14)
            plot(ZsnrEx, d_min_Smth, '.b','Markersize',M_size);
            cd(strcat(fPath,filesep,foldname));
            saveas(count_figures+3, strcat(num2str(count_trials),'_',num2str(3)),'fig')
            cd(originaldir);
            %%% END plot dmin  ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            %%%% Finding and plotting minimum point in separation  ============================================================================= %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            find_minimum_delta=min(d_min_Smth);
            element_find_minimum_delta=find((d_min_Smth)==find_minimum_delta);
            plot(ZsnrEx(element_find_minimum_delta),  d_min_Smth(element_find_minimum_delta),'Vk', 'Markersize',8)  %%% Plots minimum value found  in dmin
            text(0.7*max(ZsnrEx),0.8*min(d_min_Smth), ['Min Dmin:' num2str(d_min_Smth(element_find_minimum_delta))],'fontsize',12)



        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   CROPPING %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
    %%%%   END Finding and plotting minimum point in separation  ========================================================================%%%%%%%%%%%%%%%%
        %%%%%%% Picking range to plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if FFT_Data==0   %% Only if data is not from FFT
                %This section of code has been modified to crop automatically.
                %from approximately 0 to 2. To speed up individual curve
                %processing, use manual code below.
                x1=str2double(answer(4));
                x2=x1*10^-8;
                Pck=[1e-010,-2.4e-008;x2,-2.4e-008];

                %To select range manually, comment in the following code:
                %	[x1,y1]=ginput(2);
                %Pck=[x1 , y1];
                %Pck=sort(Pck,1); 
            end     %%% End of if for FFT data 


       %%% finding elements to crop ===============================================================================================================%%%%%
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        if FFT_Data==0   %% only if data is not from FFT, i.e. simulation FFT   
            for ii=1:1:2

            Zc_values(ii,1)=Pck(ii,1); 
            Minimum_pick(ii,1)=Pck(ii,2);
            plot(Zc_values(ii,1),  Minimum_pick(ii,1),'Vk', 'Markersize',5)    
            Minimum_error_dumb=MultiplierError*min(abs(ZsnrEx-Zc_values(ii,1)));
            Minimum_error(ii,1)=Minimum_error_dumb;

            Position_Zc_dumb=find(abs(ZsnrEx-Zc_values(ii,1))<=abs(Minimum_error_dumb),1, 'last');
            Position_Zc(ii,1)=Position_Zc_dumb; % this is the position of the vector element
            Zc_found(ii,1)=ZsnrEx(Position_Zc_dumb);
            plot(Zc_found(ii,1),  d_min_Smth(Position_Zc_dumb),'Vk', 'Markersize',5)

            end  
        else
            Position_Zc(1,1)=length(ZsnrEx)-1;
            Position_Zc(2,1)=2;
        end

       %%%%%%%%%%%%%  end looking for cropping elements =========================================================================================%%%%%%

       %%%%% plot increment deltamin  ====================================================================================================%%%%%%%%%%%%%
        if plot_data_processing_figures==1

            figure (count_figures+4)
            hold on
            plot(ZsnrEx(1:end-1),  d_min_Incr, '.r','Markersize',M_size, 'displayname','Increment Dmin');
            hold on
            box on
            title(' Increment Dmin versus zc','fontsize',12)
            xlabel('Zc','fontsize',14) 
            ylabel('Increment Dmin','fontsize',14)
            plot(ZsnrEx(1:end-1),  d_min_Incr_Smth, '.b','Markersize',M_size);    %% less smoothened but tracks   BEST USED
        end

       %%%%% END plot increment deltamin  =====================================================================================================%%%%%%%%%%%%%



         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   Calculate parameters III %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%=================== Resonance frequency AM and related ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        cosine_angle_EX=cos(PhEx*pi/180);
        sine_angle_EX=sin(PhEx*pi/180);

        if plot_data_processing_figures==1
            figure (count_figures+5)
            hold on
            plot(ZsnrEx,cosine_angle_EX,'.r','Markersize',M_size, 'displayname','cosine angle');
            hold on
            box on
            title(' Cosine and Sine versus zc','fontsize',12)
            xlabel('Zc','fontsize',14) 
            ylabel('Cosine and Sine','fontsize',14)

            plot(ZsnrEx,sine_angle_EX, '.k','Markersize',M_size); 
        end

        %%%%%% ======================================drive amplitude =========================================================================%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        A_DRIVE=(A0/omg_f0^(2))*((omg_f0^(2)-omg_drive^(2))^(2)+(omg_f0^(2)*omg_drive^(2)/Q^(2)))^(1/2); 
        Amplitude_DriveRatio_Ex=A_DRIVE./AmEx;

        %%%%%%%%   RESONANCE FREQUENCY ================================================================================================%%%%%%%%%%%%%%

        OMEGA=omg_drive/omg_f0; %% normalised natural frequency
        OMEGA_sqr=OMEGA*OMEGA;
        OMEGA_AM=(OMEGA_sqr+Amplitude_DriveRatio_Ex.*cosine_angle_EX).^(0.5)-1;  %% True resonance frequency shift 
        OMEGA_AM_Smth= smooth(OMEGA_AM,s_Omega_AM,'rloess');

        OMEGA_AM_Dif=OMEGA_AM(2:end)-OMEGA_AM(1:end-1);
        OMEGA_AM_Dif_Smth= smooth(OMEGA_AM_Dif,s_Omega_Incr,'rlowess');

        if plot_data_processing_figures==1
            figure (count_figures+6)
            hold on
            plot(ZsnrEx,  OMEGA_AM, '.r','Markersize',M_size, 'displayname','Normalised frequency shift');
            hold on
            box on
            title('Normalised frequency shift versus zc','fontsize',12)
            xlabel('Zc','fontsize',14) 
            ylabel('Normalised frequency shift','fontsize',14);       %%% from non smoothened    BEST
            text(0.7*max(ZsnrEx),0.2*max(OMEGA_AM), ['Nat. Freq. :' num2str(f0) '  Hz '],'fontsize',12)
        end

        %%%========== increment Omega AM================================================================================================= %%%%


        if plot_data_processing_figures==1
            figure (count_figures+7)
            hold on
            box on
            plot(ZsnrEx(1:end-1),  OMEGA_AM_Dif, '.r','Markersize',M_size, 'displayname','Normalised frequency shift differential');
            hold on
            title('Normalised frequency shift differential versus zc','fontsize',12)
            xlabel('Zc','fontsize',14) 
            ylabel('Normalised frequency shift differential','fontsize',14); 


        %%%%%%%%%%%%% SMOOTHING OMEGA AM =============================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%

            figure (count_figures+6)
            hold on
            plot(ZsnrEx,  OMEGA_AM_Smth, '.b','Markersize',M_size);  %%% 
            figure (count_figures+7)
            hold on
            plot(ZsnrEx(1:end-1),  OMEGA_AM_Dif_Smth, '.b','Markersize',M_size);   %%% Best 

        end
        %%%========== END increment Omega AM================================================================================================= %%%%
        %%%%%%%%%%%%=================== END Resonance frequency AM ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


        %%%%%%%%%%%%=================== Dissipative term Fi for Intergral form of Sader-Katan ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        Constant_Fi=Q*OMEGA;
        %%%%%
        Fi_Dis=-OMEGA_AM.*(Constant_Fi*Amplitude_DriveRatio_Ex.*sine_angle_EX-1);  %% This is the dissipation coefficient 
        %% Increments 
        Fi_Dis_Incr=Fi_Dis(2:end)-Fi_Dis(1:end-1);              %%% VERY NOISY

        %%% Plot F_dis=============================================================================================== %%%%%
       if plot_data_processing_figures==1
            figure  (count_figures+8)
            hold on
            box on
            plot(ZsnrEx,Fi_Dis,'.r','Markersize',M_size, 'displayname','Fi dissipation Sader');
            hold on
            title('Fi dissipation Sader versus zc','fontsize',12)
            xlabel('Zc','fontsize',14) 
            ylabel('Fi dissipation Sader','fontsize',14);  
        %%% Plot F_dis increment ===================================================================================%%%%%%%%%%

            figure  (count_figures+9)
            plot(ZsnrEx(1:end-1),Fi_Dis_Incr,'.r','Markersize',M_size, 'displayname','Fi dissipation differential Sader');
            hold on
            box on
            title('Fi dissipation differential Sader  versus zc','fontsize',12)
            xlabel('Zc','fontsize',14) 
            ylabel('Fi dissipation differential Sader','fontsize',14); 
        end


        %%%%%%%  Damping coefficient Raman and Sadar-Katan --------------------------------------------------------------------------------- %%%%%%%

        Damping_coefficient=gamma_medium*(A0./AmEx.*sine_angle_EX-1);

        if plot_data_processing_figures==1
            figure (count_figures+10)
            hold on
            box on
            plot(ZsnrEx, Damping_coefficient,'.r','Markersize',M_size,'displayname','Damping');
            title(' Damping effective coefficient versus zc','fontsize',12)
            xlabel('Zc','fontsize',14) 
            ylabel('Damping effective coefficient','fontsize',14); 
        end


        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%=================== CROPED SECTION STARTS BELOW For numerical simulation ==================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        Damping_coefficient_crop=Damping_coefficient(Position_Zc(2,1):Position_Zc(1,1));	
        ZsnrEx_crop=ZsnrEx(Position_Zc(2,1):Position_Zc(1,1));
        AmEx_crop=AmEx(Position_Zc(2,1):Position_Zc(1,1));		
        AmEx_mean_crop=(AmEx_crop(1:end-1)+AmEx_crop(2:end))/2;
        cosine_angle_EX_crop=cosine_angle_EX(Position_Zc(2,1):Position_Zc(1,1));
        sine_angle_EX_crop=sine_angle_EX(Position_Zc(2,1):Position_Zc(1,1));

        d_min_crop=d_min(Position_Zc(2,1):Position_Zc(1,1));				% This is the raw data for dmin
        d_min_Smth_crop=d_min_Smth(Position_Zc(2,1):Position_Zc(1,1));      % This one can be chosen rather than the top to smoothen dmin  
        d_min_Incr_crop=d_min_Incr(Position_Zc(2,1):Position_Zc(1,1));     %%% This is the raw data for dmin Incr
        OMEGA_AM_crop=OMEGA_AM(Position_Zc(2,1):Position_Zc(1,1));
        OMEGA_AM_Dif_crop=OMEGA_AM_Dif(Position_Zc(2,1):Position_Zc(1,1));  % raw data

        %%%%% Mean values for numerical integration %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        d_min_mean_crop=(d_min_crop(1:end-1)+d_min_crop(2:end))/2;         %% mean value for integration  
        OMEGA_AM_mean_crop=(OMEGA_AM_crop(1:end-1)+ OMEGA_AM_crop(2:end))/2;


        %%%%%%%%%%%%%%%%%% SAVE FILES the files related to processing ABOVE  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        if save_files_processing==1    %% save files automatically
            cd(strcat(fPath,filesep,foldname));
            for iii=1:10
            saveas(count_figures+iii, num2str(iii),'fig')	
            end
            cd(originaldir);
        end


        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%=================== SOLVE EQUATION BELOW KATAN SADER OR RAMAN ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        if Sader_Katan==1			%% This is the Sader-Katan method


            %%%%%%%%%%%%%%%%%%%%%%%% SADER KATAN DEFINITION PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Fts_cons_crop_Smth=zeros(length(ZsnrEx_crop),1);			%% This is smoothened
            Fts_cons_crop_raw=zeros(length(ZsnrEx_crop),1);
            Integral_Fts_dis_crop_Smth=zeros(length(ZsnrEx_crop),1);	%% this is smoothened
            Integral_Fts_dis_crop_raw=zeros(length(ZsnrEx_crop),1);

        %%% raw %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            I_1_crop_raw=zeros(length(ZsnrEx_crop),1);
            I_2_crop_raw=zeros(length(ZsnrEx_crop),1);
            I_1_dis_crop_raw=zeros(length(ZsnrEx_crop),1);
            I_2_dis_crop_raw=zeros(length(ZsnrEx_crop),1);
        %% smoothened
            I_1_crop_Smth=zeros(length(ZsnrEx_crop),1);
            I_2_crop_Smth=zeros(length(ZsnrEx_crop),1);
            I_1_dis_crop_Smth=zeros(length(ZsnrEx_crop),1);
            I_2_dis_crop_Smth=zeros(length(ZsnrEx_crop),1);

        %%%% Dissipation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            Fi_Dis_crop=Fi_Dis(Position_Zc(2,1):Position_Zc(1,1));
            Fi_Dis_Incr_crop=Fi_Dis_Incr(Position_Zc(2,1):Position_Zc(1,1));   % This is raw
            Fi_Dis_mean_crop=(Fi_Dis_crop(1:end-1)+Fi_Dis_crop(2:end))/2;



        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SADER-KATAN PARAMETERS FORCE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% BELOW SOLVES EQUATION SADER KATAN %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


         for iii=1:1:length(ZsnrEx_crop)-1
            for ppp=1:1:iii

                    I_1_crop_raw(ppp,1)=(1+(AmEx_mean_crop(ppp,1))^(0.5)/8/(sqrt(pi*(d_min_mean_crop(ppp,1)-d_min_crop (iii+1,1)))))*OMEGA_AM_mean_crop(ppp,1)*d_min_Incr_crop(ppp,1);
                    I_2_crop_raw(ppp,1)=-(AmEx_mean_crop(ppp,1))^(1.5)/(sqrt(2*(d_min_mean_crop(ppp,1)-d_min_crop (iii+1,1))))*OMEGA_AM_Dif_crop(ppp,1);

                    I_1_dis_crop_raw(ppp,1)=(1+(AmEx_mean_crop(ppp,1))^(0.5)/8/(sqrt(pi*(d_min_mean_crop(ppp,1)-d_min_crop (iii+1,1)))))*Fi_Dis_mean_crop(ppp,1)*d_min_Incr_crop(ppp,1);
                    I_2_dis_crop_raw(ppp,1)=-(AmEx_mean_crop(ppp,1))^(1.5)/(sqrt(2*(d_min_mean_crop(ppp,1)-d_min_crop (iii+1,1))))*Fi_Dis_Incr_crop(ppp,1);

                    Fts_cons_crop_raw(iii,1)= Fts_cons_crop_raw(iii,1)-2*k*(I_1_crop_raw(ppp,1)+I_2_crop_raw(ppp,1));

                    Integral_Fts_dis_crop_raw(iii,1)=Integral_Fts_dis_crop_raw(iii,1)+(I_1_dis_crop_raw(ppp,1)+I_2_dis_crop_raw(ppp,1));
            end
         end

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%=================== END. SOLVE EQUATION BELOW ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %%%% =====================================================================================================================================%%%%%%%%%%
        Fts_dis_Incr_crop_raw=abs(Integral_Fts_dis_crop_raw(2:end)-Integral_Fts_dis_crop_raw(1:end-1));
        Fts_dis_crop_raw=-abs(gamma_medium*(Fts_dis_Incr_crop_raw./d_min_Incr_crop(2:end)));

        %%%%%%%%%%%%=================== PLOTTING FORCES ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %%%%%%%%=============== CONSERVATIVE FORCE AND DAMPING COEFFICIENT ======================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%% CONSERVATIVE DISSIPATIVE  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        if Smooth_raw_data==0		%% this is typically simulation
            figure (count_figures+11)
            hold on
            plot(d_min_crop,Fts_cons_crop_raw,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
            hold on
            box on
            title('Force Sader and damping coefficient versus zc','fontsize',12)
            xlabel('dmin','fontsize',14) 
            ylabel('Conservative force','fontsize',14); 

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%% Get rid of infs, nans and zeros %%%%%%%%
            DUMMY_YY=zeros(length(Fts_cons_crop_raw));
            DUMMY_XX=zeros(length(d_min_crop));
            DUMMY_YY=Fts_cons_crop_raw;
            DUMMY_XX=d_min_crop;
            GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
            Fts_cons_crop_raw_real=DUMMY_YY_real;
            d_min_crop_real=DUMMY_XX_real;	

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%% Smoothen %%%%%
            Fts_cons_crop_ss=smooth(Fts_cons_crop_raw_real,ss_Fts_cons_S_K,'rloess');				%%% This does not Smoothen properly anyway if complex and NANS % What ends us with S is smooth from final curve not smoothed data 		
            plot(d_min_crop_real,Fts_cons_crop_ss,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');	
            Fts_cons_crop_ss_min=min(Fts_cons_crop_ss(floor(0.1*(length(Fts_cons_crop_ss))):floor(0.90*(length(Fts_cons_crop_ss)))));
    %         Fts_cons_crop_ss_min_foo=Fts_cons_crop_ss(floor(0.1*(length(Fts_cons_crop_ss))):floor(0.90*(length(Fts_cons_crop_ss))));
            F_adhesion=Fts_cons_crop_ss_min;
    %         
    % 		if Fts_cons_crop_ss_min==Fts_cons_crop_ss(end)
    %             break;
    %         else
    %         end

            %%%%% damping %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Damping_coefficient_crop_ss=smooth(Damping_coefficient_crop,ss_Damping_Coeff,'rloess');
            plot(d_min_crop,Damping_coefficient_crop,'.k','Markersize',M_size, 'displayname','Damping coefficient raw');
            plot(d_min_crop,Damping_coefficient_crop_ss,'.c','Markersize',M_size, 'displayname','Damping coefficient Smooth');
            Damping_coefficient_crop_ss_max=max(Damping_coefficient_crop_ss(floor(0.1*(length(Damping_coefficient_crop_ss))):floor(0.95*(length(Damping_coefficient_crop_ss)))));

            text(0,1.2*abs(F_adhesion), ['Max damping :' num2str(Damping_coefficient_crop_ss_max), ' Ns/m'],'fontsize',12)
            text(0,0.8*abs(F_adhesion), ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)	
            axis([(d_min(end)-1e-9) d_min(1) -abs(1.2*F_adhesion) abs(2*F_adhesion)])

        else

        %%%% Needs to be smoothened with decreasing d_min_crop ALSO remove zeros etc.  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%% Figure 11 conservative  and dissipative coefficient Sader-Katan %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Smoothen_Sader_Katan_Force;   %% This plots conservative damping and integral damping raw and also smoothend

        %%%% Inside Smoothen_Sader the flag flag_failed_F_Adhesion will be actiavted if mistake in Force of Adhesion
        end

        if flag_failed_F_Adhesion==0 %%%% Error in force of adhesion

        %%%%% integral DISSIPATIVE COEFFICIENT form ======================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            if Smooth_raw_data==0   %%% If 1 everything here is plotted in the Smoothen_Sader_Katan_Force file

                figure (count_figures+12)
                hold on
                plot(d_min_crop,Fts_cons_crop_raw,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
                plot(d_min_crop_real,Fts_cons_crop_ss,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');
                plot(d_min_crop(1:end-1),Fts_dis_crop_raw,'.k','Markersize',M_size, 'displayname','Dissipative coefficient: Sader Integral:raw');
                hold on
                box on
                title('Effective Integral coefficient','fontsize',12)
                xlabel('dmin','fontsize',14) 
                ylabel('Dissipative coefficient: Integral','fontsize',14); 

                %%% Smooth %%%%%%%
                Fts_dis_crop_raw_s=smooth(Fts_dis_crop_raw,s_Fts_dis_s,'rloess'); %	
                Fts_dis_crop_raw_max=max(Fts_dis_crop_raw_s(floor(0.1*(length(Fts_dis_crop_raw_s))):floor(0.95*(length(Fts_dis_crop_raw_s)))));
                plot(d_min_crop(1:end-1),Fts_dis_crop_raw_s,'.c','Markersize',M_size,'displayname','Dissipative coefficient: Integral_smooth');


                text(0,0.8*abs(F_adhesion), ['Max Damping:' num2str(Fts_dis_crop_raw_max), ' Ns/m'],'fontsize',12)
                text(0,0.4*abs(F_adhesion), ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
                axis([(d_min(end)-1e-9) d_min(1) -abs(1.2*F_adhesion) abs(2*F_adhesion)])


                if Use_smoothening==1   %% this is smoothended
                    plot(d_min_Smth_crop(1:end-1),Fts_dis_crop_Smth,'.b','Markersize',4,'displayname','Dissipative coefficient: Integral smooth');
                end

            end


            %%%%% END integral DISSIPATIVE COEFFICIENT form ======================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%% End PLotting conservative and damping coefficient for smoothened data ==========================================================%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


            %%%%%%%%%%%%%%% Save files %%%%%%%%%%%%%%%%

                if save_files_Sader_Katan==1    %% save files automatically
                    cd(strcat(fPath,filesep,foldname));
                    for iii=11:12
                    saveas(count_figures+iii,strcat(num2str(count_trials),'_',num2str(iii)),'fig')	
                    end
                    cd(originaldir);
                end

            end
        end %%%% End of Sader Katan method 

%         if flag_failed_F_Adhesion==1 %%%% Error in force of adhesion
%     
%             cd(fPath);
%             
%             if exist(foldname, 'dir')
%                 rmdir(foldname, 's');  %delete everything in it!
%             end
%             
%             dummy_file=strcat(foldname, '.txt');
%             
%             if exist(dummy_file, 'file')
%                 delete(dummy_file);
%             end
%         end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%=================== Analytical  such as Energy dissipation, Virial, etc. ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if flag_failed_F_Adhesion==0 %%%% Error in force of adhesion

            if Further_Analysis==1


                if Smooth_raw_data==1   %%% 

                    Sorting_dmin_for_Smothening;		%%%	This will be used in the Analytical Analysis file

                end

                Analytical_analysis;


                if save_files_further_analysis==1    %% save files automatically
                    cd(strcat(fPath,filesep,foldname));
                    for iii=50:59
                    saveas(count_figures+iii,strcat(num2str(count_trials),'_',num2str(iii)),'fig')	
                    end
                    cd(originaldir);
                end

                if save_extra_analysis==1    %% save files automatically
                    cd(strcat(fPath,filesep,foldname));
                    for iii=20:27
                    saveas(count_figures+iii,strcat(num2str(count_trials),'_',num2str(iii)),'fig')	
                    end
                    cd(originaldir);
                end

                if Quantification==1
                    cd(strcat(fPath,filesep,foldname));
                    for iii=70:72    %%%% Beware of Plot_process_quantification being 1 in Quantification Parameters file. If so then 70-78.. 73-78 is a nonlinear fit
                        saveas(count_figures+iii,strcat(num2str(count_trials),'_',num2str(iii)),'fig')	
                    end
                    cd(originaldir);
                end



            else   %%%% If further analysis on dissipation is off but other like elastic modulus is on


                if Smooth_raw_data==1   %%% 

                    Sorting_dmin_for_Smothening;		%%%	This will be used in the Analytical Analysis file

                end

                if Sader_Katan==1
                D_shift=D_min_zero_found;
                Fts_S_K_cons_norm=Fts_cons_crop_raw/abs(F_adhesion);
                Fts_S_K_cons_norm_ss=Fts_cons_crop_sorted_ss/abs(F_adhesion);
                min_d_plot=d_min_crop_sorted_zeroed(end)-1e-9;
                max_d_plot=d_min_crop_sorted_zeroed(1);

                D_M_ZEROED_CROP=d_min_crop-D_shift;
                D_M_ZEROED=d_min-D_shift;

                D_M_ZEROED_CROP_d=d_min_crop_d-D_shift;
                D_M_ZEROED_d=d_min_d-D_shift;
            else    %% This is if we do not have force to calculate Fa or if there is no simulation
                D_shift=0;
            end

            ss_Edis=0.01; 
            ss_Virial=0.02;
            ss_Derivative=0.02;
            ss_Derivative_crop=0.02; 
            Derivative_points=1;  %% How many points in dmin to calculate derivative Fig. ss_derivative_dmin
            ss_angle_cons=0.01;
            ss_phase=0.02;
            ss_Edis_Ph=0.01;
            ss_Edis_Ph_crop=0.01;
            ss_Damp_Coeff=0.01;
            ss_OMEGA=0.02;
            ss_phase_diff=0.08;
            ss_amplitude_d=0.01; % Figure in qunatification Figure 70


            %%%%%%%% Prepare vectors %%%%%%%%%%%%%%%%%%%%
            A_norm=AmEx/A0;
            A_norm_crop=A_norm(Position_Zc(2,1):Position_Zc(1,1));

            if save_quantification==1
                cd(strcat(fPath,filesep,foldname));
                    for iii=70:72    %%%% Beware of Plot_process_quantification being 1 in Quantification Parameters file. If so then 70-78.. 73-78 is a nonlinear fit
                        saveas(count_figures+iii, strcat(num2str(count_trials),'_',num2str(iii)),'fig')	
                    end
                cd(originaldir);
            end

            end

            if Calculate_elastic_modulus==1;

                ElasticModulus;
                cd(strcat(fPath,filesep,foldname));
                for iii=101:103    %%%% Beware of Plot_process_quantification being 1 in Quantification Parameters file. If so then 70-78.. 73-78 is a nonlinear fit
                        saveas(count_figures+iii,strcat(num2str(count_trials),'_',num2str(iii)),'fig')	
                end
                cd(originaldir);

            end



            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%=================== RAMAN reconstruction below ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            if Raman==1	

                Raman_force;

                %%%%%%%%%%%%%%% Save files %%%%%%%%%%%%%%%%

                if save_files_Raman==1    %% save files automatically
                    cd(strcat(fPath,filesep,foldname));
                    for iii=13:14
                    saveas(count_figures+iii, strcat(num2str(count_trials),'_',num2str(iii)),'fig')	
                    end
                    saveas(count_figures+iii, strcat(num2str(count_trials),'_','40'),'fig')	
                    cd(originaldir);
                end

            end

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%=================== Load simulation forces at the end ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            if Load_simulation_forces==1

                load_sim_forces;

            end


            %count_figures=count_figures+1000;

        end  %%%% End of flag, i.e. adhesion failed 
    
    end  
    
    if flag_failed_F_Adhesion==0 %%%% Error in force of adhesion

        if Calculate_elastic_modulus==1
                E_m_NN=output_ElasticM_mean*1e-9;
                E_m_NN_sd=output_ElasticM_std*1e-9;
                E_m_Al=Chauvenete_ElasticM_mean*1e-9;
                E_m_Al_sd=Chauvenete_ElasticM_std*1e-9;

                E_m_NN_single=output_ElasticM_mean_single*1e-9;
                E_m_NN_single_sd=output_ElasticM_std_single*1e-9;


                strFileSpec = sprintf( 'Elasticity%u', counter_m );
                save( strFileSpec, 'E_m_NN', 'E_m_NN_sd', 'E_m_Al', 'E_m_Al_sd', ...
                    'flag_correct_YM','E_m_NN_single', 'E_m_NN_single_sd', ...
                    'flag_complex', 'flag_complex_single', 'correction_Indentation');

                counter_m=counter_m+1;

                c_mine=counter_m-1;
                thismat = sprintf( 'NumberOfFiles');
                save ( thismat, 'c_mine');
        end  


        if save_numerical_values==1


            zero_position=find(D_M_ZEROED_CROP==0);


            Edis_max_notcropped=Edis_max_T;
            Edis_max_croped=Edis_max;

            E_dis_at_adhesion_foo=Edis_crop(zero_position);
            Virial_at_adhesion_foo=Virial_Fts_crop(zero_position);
            %%%% Find the value of Edis coinciding with F_adhesion or fmin 
            E_dis_at_adhesion=E_dis_at_adhesion_foo(1);
            %%%% Virial coinciding with the point of adhesion  
            Virial_at_adhesion=Virial_at_adhesion_foo(1);

            %%%%%%%%%%%%%%%%%

            strFileSpec = sprintf( 'Numerical_data%u',  counter_analytical_stuff );
            save( strFileSpec, 'F_adhesion', 'Edis_max_notcropped', 'Edis_max_croped', 'Virial_Fts_max', ...
            'E_dis_at_adhesion', 'Virial_at_adhesion');

            counter_analytical_stuff=counter_analytical_stuff+1;

            c_mine_2=counter_analytical_stuff-1;
            thismat_2 = sprintf( 'NumberOfFiles_2');
            save ( thismat_2, 'c_mine_2')

        end

        %%% move txt file into cooresponding folder %%%%
        destination_foo=strcat(fPath,filesep,foldname, '\', foldname , '.txt');     
        movefile(fNames{counter_files_done},destination_foo,'f');
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %%%%% Move folder inside folder of data %%%%%%%%%%%%%%%%%%%%%%%%%%
        original_folder_foo=strcat(fPath,filesep,foldname);
        destination_folder_foo=strcat(fPath,'\DATA_FOLDER',filesep,foldname);
        movefile(original_folder_foo,destination_folder_foo,'f');

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        if save_final_vectors==1
            single_curves = sprintf( 'Single_file%i', counter_files_done);
            cd(destination_folder_foo);

            if Calculate_elastic_modulus==1
                save ('single_curves', 'ZsnrEx','d_min', 'D_M_ZEROED_CROP', 'Edis_norm_crop_ss', ...
                    'd_min_crop_sorted_zeroed', 'Edis_max', 'Fts_S_K_cons_norm_ss', 'F_adhesion', ...
                    'A_norm_crop', 'A0', 'Phase_difference_crop_norm_ss_r', 'max_PD_crop', ...
                    'Phase_Energy_crop_norm_ss', 'Phase_Energy_max', 'Damping_coefficient_crop_ss_r_norm', ...
                    'Damping_coefficient_crop_ss_r_max', 'OMEGA_AM_crop_ss_norm', 'OMEGA_AM_crop_ss_min');
            else
            
                save ('single_curves','correction_Indentation', '-append');
            
            end
            
            cd(originaldir);
        end 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        counter_files_done=counter_files_done+1;
        close all                     % closes all figures

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    elseif (flag_failed_F_Adhesion==1&&Break_error==1)  %%% if F_adhesion smoothen failed
            break;
    elseif (flag_failed_F_Adhesion==1&&Break_error==0) 
                  
    end

        
end


toc


