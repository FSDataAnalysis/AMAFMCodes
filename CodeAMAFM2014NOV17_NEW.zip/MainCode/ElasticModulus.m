% clear all;
% load foo;
% close all;
% clc;

Select_adhesion_point_manually_ElasticM=1;
NonLinear_ElasticM=1;  %% Calculates Elastic Modulus as nonlinear regression function from Matlab 
CONFIDENCE_INTERVAL_ElasticM=0.05;
M_size_E=7;
a0=0.165e-9; %%% Intermolecular distance
%%%%%%%%%%%%%%% Clean figure %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


figure (count_figures+101)
hold on
box on


if Sader_Katan==1
		
		hold on
		plot(D_M_ZEROED_CROP,Fts_S_K_cons_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');
		axis([ min_d_plot  max_d_plot -1.2 2])	
		text(1e-9,0.8, ['A0 :' num2str(A0*1e9) '  nm'],'fontsize',12);
		text(1e-9,0.4, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
else

		text(1e-9,0.6, ['A0 :' num2str(A0*1e9) '  nm'],'fontsize',12);
		axis([ d_min(1) d_min(end)  0 1.2])
end


%% pick points to crop %%%%%%

%%%% e stands for elastic modulus 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if Select_adhesion_point_manually_ElasticM==1   % This allows you pick three points, i.e. adhesion and two for range
    
    title('Elastic Modulus: Pick Range Indentation and zero load','fontsize',12)

    dumb_pos=Position_Fa;   %% this is the position of the "automatically chosen minimum force 

    Pck_e=[d_min_crop_sorted_zeroed(end-subtract_EModulus) ...
        Fts_S_K_cons_norm_ss(end-subtract_EModulus); ...
        d_min_crop_sorted_zeroed(dumb_pos+add_EModulus) ...
        Fts_S_K_cons_norm_ss(dumb_pos+add_EModulus); ...
        d_min_crop_sorted_zeroed(dumb_pos) Fts_S_K_cons_norm_ss(dumb_pos)];

    lll=length(d_min_crop_sorted_zeroed);

    final_pos_is=lll-subtract_EModulus;
    initial_pos_is=dumb_pos+add_EModulus;
    position_at_minima=dumb_pos;

    Position_d_dumb_ElasticM=([final_pos_is initial_pos_is position_at_minima])';

    % %%%%%% Prepare vectors to calculate K %%%%%%%%%%%%%%%%%%%%
    EE1=Position_d_dumb_ElasticM(2,1);
    EE2=Position_d_dumb_ElasticM(1,1); 

    Position_Adhesion=Position_d_dumb_ElasticM(3,1);
    Picked_Adhesion=Fts_S_K_cons_norm_ss(Position_Adhesion);
    Picked_Adhesion_abs=abs(Picked_Adhesion*F_adhesion);

    e_Force=Fts_S_K_cons_norm_ss;
    e_Indentation=d_min_crop_sorted_zeroed;

    % %%% Standard  International Units %%%%%%

    e_Force_IU=Fts_S_K_cons_norm_ss*(abs(F_adhesion));

    e_Indentation_IU=abs(d_min_crop_sorted_zeroed(EE1:EE2)-d_min_crop_sorted_zeroed(Position_Adhesion));

    e_load_IU=e_Force_IU(EE1:EE2)+abs(F_adhesion);

    Constant_e=3/4*R^(-0.5);


    Elastic_Modulus_Analytic=Constant_e*(e_load_IU.*(e_Indentation_IU.^(-1.5)));
    Elastic_Modulus_Analytic_dumb=Elastic_Modulus_Analytic;

    % %%%% REMOVE NANS ETC %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%  curve raw %%%%
        DUMMY_YY=zeros(length(Elastic_Modulus_Analytic));
        DUMMY_XX=zeros(length(e_Indentation_IU));
        DUMMY_YY=Elastic_Modulus_Analytic;
        DUMMY_XX=e_Indentation_IU;

        GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
        E_real=DUMMY_YY_real;
        Indentation_real=DUMMY_XX_real;



    Elastic_Modulus_Analytic_mean=mean(E_real);
    Elastic_Modulus_Analytic_std=std(E_real);

    %%%% remove outliers %%%%%%%

        Data_input=E_real;

        Chauvenete;
        Outliers_E_vector=c19;

    Chauvenete_ElasticM_mean=mean(Data_input);
    Chauvenete_ElasticM_std=std(Data_input);


    %%%%%%%%%%%%% END OF ESTIMATING ELASTIC MODULUS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%% FIND THE LOCATION OF REPULSIVE FORCES TO FIT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % DUMB_cut_off_force=0.2;

    %%%% Look "After adhesion point" %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    if find_d_is_zero_DMT==1 
        hold on;
        Fts_S_K_cons_norm_ss_foo=Fts_S_K_cons_norm_ss(Position_Adhesion:end);

        Minimum_error_f=MultiplierError*min(abs(Fts_S_K_cons_norm_ss_foo+DUMB_cut_off_force)); %%% check error for match
        %%% check position of cut off
        Position_force_0XFAD_foo=find(abs(Fts_S_K_cons_norm_ss_foo+DUMB_cut_off_force)<=abs(Minimum_error_f),1, 'first');

        Position_force_0XFAD=Position_Adhesion+Position_force_0XFAD_foo;

        minimum_distance_new=d_min_crop_sorted_zeroed(Position_force_0XFAD);
        plot(minimum_distance_new,  Fts_S_K_cons_norm_ss(Position_force_0XFAD),'Vk','Linewidth', 4, 'Markersize',6)
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%% END FIND THE LOCATION OF REPULSIVE FORCES TO FIT
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%----------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%% Minimum position to fit HAS CHANGED TO Position_force_0XFAD at minimum_distance_new 
    %%%% EXPLANATION: IF FITTING AFTER THIS POINT ERRORS MIGHT OCCUR BECAUSE
    %%%% CONTACT HAS NOT OCCURRED YET %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%% DEFINITION NEW INDENTATIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % %%%%%% Prepare vectors to calculate K %%%%%%%%%%%%%%%%%%%%
    EE1_new=Position_force_0XFAD;
    EE2_new=EE2; 

    % %%% Standard  International Units %%%%%%

    e_Indentation_IU_new=abs(d_min_crop_sorted_zeroed(EE1_new:EE2_new)-d_min_crop_sorted_zeroed(Position_Adhesion));

    e_load_IU_new=e_Force_IU(EE1_new:EE2_new)+abs(F_adhesion);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % real_Indentation_IU=(e_Indentation_IU_new+epsilon);

    %%%%%%

    Constant_1_DMT=4/3*(R^(0.5));

    %%%%%% FUNCT IS TRSNSFORMED %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %% Force(DMT)+F(ADHESION)=4/3*E*R^0.5*Indentation^1.5

        %% F=a*E*Indentation^1.5 => (F/a)=E*(Indentation-a0)^1.5
        %% (F/a)_eff=(F/a)*1e6/31.6228 // E_eff=E*1e-9 // (Indentation -a0)_eff=(Indentation -a0)*1e9;
        %% FINALLY
        %% (F/a)_eff=func=E_eff*(Indentation -a0)_eff^1.5

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    a0_eff=a0*1e9;
    e_load_normalized=(e_load_IU_new/Constant_1_DMT)*1e6/31.6228;

    flag_correct_YM=0;
    flag_complex=0;
    flag_complex_single=0;
    
    if NonLinear_ElasticM==1 %%% Non linear fit for elastic modulus


        y=e_load_normalized;
        dy = y*CONFIDENCE_INTERVAL_ElasticM;

        x_eff=e_Indentation_IU_new*1e9;  %% nm
        x=x_eff;    % 

        %%% formula converted to the the inline version
        %%%  Here p(1) is the elastic modulus and p(2) is epsilon, 
        %%% i.e. the intermolecular distance used to find real zero indentation
        func = inline('p(1).*((x(:,1)-p(2)).^(1.5))','p','x');   

        Chauvenete_ElasticM_mean_eff_times=Chauvenete_ElasticM_mean*1e-9;
        p0 = [Chauvenete_ElasticM_mean_eff_times a0_eff];

        %To detect the sensitivity of the fit to starting parameter guess,
        %the fit is run a number of times.
        %each fit is plotted and each parameter plotted as a histogram
        Nrepeat=10;
        %each parameter is varied by a normal distribution with
        %mean equal to the starting guess and std.dev. equal to
        %sd*mean
        sd = 0.3;
        %histogram zoom factor (how many std dev to show)
        zfactor = 2;
        %parameter outlier cuttoff: lowest and highest N estimates are removed
        outcut=10;
        %========================================================
        %END settable inputs
        %========================================================
        terms=2;
        %list of all parameter outputs to use in histogram
        pList=zeros(Nrepeat,terms);


        for rep =1:Nrepeat
            %     rep

            %form the new randomized start vector
            p = [p0(1)*(1+sd*randn)  p0(2)*(1+sd*randn)];  %% REGRESSION of two parameters Elastic modulus and a0. 
            %do the fit
            [p,r,j] = nlinfit(x,y,func,p);
            %copy fit to list
            pList(rep,:) = p';

           %%%% get parameter errors
            
            if (isreal(r)==0||isreal(p)==0||isreal(j==0))       
                flag_complex=1;
               
            else
                c95 = nlparci(p,r,j);
                [yp, ci] = nlpredci(func,x,p,r,j);
            end
            
           

        end


        
        
        %%%%%%%%%%%%%%%%%%% REGRESION AND CONFIDENCE INTERVALS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        if isempty(pList)  
             flag_correct_YM=0;
       
        else
             flag_correct_YM=1;
        end
       
        if flag_correct_YM==1 
            
            figure (count_figures+102)
            hold on 
            box on
            title(' Elastic Modulus: NONLINEAR REGRESSION','fontsize',12)
            xlabel('Indentation','fontsize',14) 
            ylabel('Force: NonLinear NORMALIZED Y AXIS','fontsize',14)

            foo_correct_ind=abs(mean(pList(:,2)));
            foo_correct_ind_std=abs(std(pList(:,2)));

            correction_Indentation=foo_correct_ind*1e-9; %d_min_crop_sorted_zeroed(Position_Adhesion);
            correction_Indentation_std=foo_correct_ind_std*1e-9;

            e_Indentation_IU_new_corrected=e_Indentation_IU_new-correction_Indentation;

            e_dumb_is=abs(e_Indentation_IU_new_corrected(1))*1e9;
            min_indentation=e_Indentation_IU_new_corrected(1)*1e9;
  
            if e_dumb_is>=0  %%% Implies indentations are positive, otherwise there is an error 

                
                flag_correct_YM=1;

                if flag_complex==0
                    errorbar(e_Indentation_IU_new_corrected,func(p,x),ci,ci,'b-');			% fit

                    hold on

                    errorbar(e_Indentation_IU_new_corrected,y,dy,dy,'ro')		%% real 
        
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                figure (count_figures+103)
                hold on 
                box on

                output_ElasticM_mean=abs(mean(pList(:,1))*1e9);
                output_ElasticM_std=abs(std(pList(:,1))*1e9);
                format shortEng

                figure (count_figures+103)
                hold on 
                box on

                d_min_corrected_DMT=d_min_crop_sorted_zeroed+correction_Indentation;

                d_minus_find=find(d_min_corrected_DMT<=0);

                Indentation_corrected_DMT=-d_min_corrected_DMT(d_minus_find);
                Force_added_DMT=Fts_S_K_cons_norm_ss(Position_force_0XFAD)*abs(F_adhesion);
                Force_IU_corrected=e_Force_IU(d_minus_find)+Force_added_DMT;


                Force_nl_reconstructed_DMT=Constant_1_DMT*output_ElasticM_mean*(Indentation_corrected_DMT.^(1.5));

                Force_nl_reconstructed_net=Force_nl_reconstructed_DMT+F_adhesion;
                Force_nl_reconstructed_net_norm=Force_nl_reconstructed_net/abs(F_adhesion);

                plot(-Indentation_corrected_DMT,Force_nl_reconstructed_net_norm,'Vk','Markersize',M_size_E, 'displayname',' NONLINEAR FIT From ElasticM (DMT): Force');

                text(1e-9,-1.4, ['ElasticM (DMT) NN:' num2str(output_ElasticM_mean*1e-9) '  GPa'],'fontsize',12);
                text(1e-9,-1.8, ['ElasticM (DMT) NN (std) :' num2str(output_ElasticM_std*1e-9) '  GPa'],'fontsize',12);
                axis([ min_d_plot  max_d_plot -2 2])

            else  % INSIDE ONLY IF CORRECT INDENATION otherwise next 

                flag_correct_YM=0;
            end
        end

    end   % NONLINEAR REGRESSION


    if flag_correct_YM==0
        correction_Indentation=0;
    end
        
    %%%%%%%%%%%%%% STATS FOR INITIAL ESTIMATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure (count_figures+103)
    hold on 
    box on
    plot(D_M_ZEROED_CROP+correction_Indentation,Fts_S_K_cons_norm*abs(F_adhesion)/Picked_Adhesion_abs,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
    plot(d_min_crop_sorted_zeroed+correction_Indentation,Fts_S_K_cons_norm_ss*abs(F_adhesion)/Picked_Adhesion_abs,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');

    title(' Elastic Modulus: FIT','fontsize',12)
    axis([ min_d_plot  max_d_plot -2 2.2])	

    text(1e-9,1.2, ['Range Indentation :' num2str(e_Indentation_IU(1)*1e9) ' to ' num2str(e_Indentation_IU(end)*1e9) '  nm'],'fontsize',12);
    text(1e-9,0.8, ['A0 :' num2str(A0*1e9) '  nm'],'fontsize',12);
    text(1e-9,0.4, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)

    %%%%%% Plot Fit from Analytic 

    Force_Analytic_FIT=4/3*Chauvenete_ElasticM_mean*(R^(0.5))*(e_Indentation_IU.^(1.5));


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%  Calculating error Elastic modulus anlytic  fit and non linear  %%%%%%%%%


    %%%%%%%% INITIAL ESTIMATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure (count_figures+103)
    hold on 
    box on
    Force_Analytic_FIT_total_norm=Force_Analytic_FIT/Picked_Adhesion_abs +F_adhesion/Picked_Adhesion_abs;
    Force_total_norm =e_load_IU/Picked_Adhesion_abs+F_adhesion/Picked_Adhesion_abs;
    % Difference_squared_force_fit=(((Force_total_norm-Force_Analytic_FIT_total_norm)./Force_total_norm).^2);
    Difference_squared_force_fit=(((Force_total_norm-Force_Analytic_FIT_total_norm)/max(abs(Force_total_norm))).^2);
    % 
    Data_input=Difference_squared_force_fit;

    Chauvenete;
    Sum_squared_force_fit=sum(Data_input);
    force_fit_points=length(Data_input);

    Standard_deviation_error_force_fit=floor(sqrt(1/force_fit_points*(Sum_squared_force_fit))*100);
    % 
    %     text(0,1.6, ['ERROR ANALTIC FIT (STD): ' num2str(Standard_deviation_error_force_fit), ' %'],'fontsize',15);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%% NON_LINEAR ESTIMATION E only %%%%%%%%%%%%%%%%

    E_Modulus_single_fit;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



    if NonLinear_ElasticM==1

        if flag_correct_YM==1;

            Force_total_norm_nl=Force_IU_corrected/(abs(F_adhesion));

            Difference_squared_force_nl_fit=(((Force_nl_reconstructed_net_norm - ...
                 Force_total_norm_nl)).^2);


            Data_input=Difference_squared_force_nl_fit;

            Chauvenete;
            Sum_squared_force_nl_fit=sum(Data_input);
            force_nl_fit_points=length(Data_input);

            Standard_deviation_error_force_nl_fit=floor(sqrt(1/force_nl_fit_points*(Sum_squared_force_nl_fit)));

            text(0,2, ['ERROR NL FIT (STD): ' num2str(Standard_deviation_error_force_nl_fit), ' %'],'fontsize',15);

        else    %%% There as been an error in the NonLinear Regression

            if flag_complex_single==1
                
               output_ElasticM_mean=Chauvenete_ElasticM_mean;
               Standard_deviation_error_force_nl_fit=Chauvenete_ElasticM_std;
                
            else
                
               output_ElasticM_mean=output_ElasticM_mean_single;
               Standard_deviation_error_force_nl_fit=output_ElasticM_std_single;
                
            end    

            text(1e-9,-1.4, ['ERROR YM:' num2str(output_ElasticM_mean*1e-9) '  GPa'],'fontsize',12);
            text(0,2, ['ERROR YM (STD): ' num2str(output_ElasticM_std_single), ' %'],'fontsize',15);

        end

    end


end
