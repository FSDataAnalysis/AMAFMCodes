
%%% The outcome of this is to find a set of d min values to use for polynomial expansion. Saved in Position_d_min  as elements of the vector 

Set_Raman=[d_min_Raman, AmEx_Raman, cosine_Raman, ZsnrEx_Raman, sine_Raman];

%Range_d_min_Raman=abs(D_min-D_max);
%Distance_in_d_min=(Range_Raman/N_Chebyshev);
Range_zc_Raman=abs(ZsnrEx_Raman(L)-ZsnrEx_Raman(1));

if N_Chebyshev==1
	Distance_in_zc=((Range_zc_Raman)/(N_Chebyshev));
end
if N_Chebyshev>1
	if N_Chebyshev>5
		Distance_in_zc=((Range_zc_Raman)/(N_Chebyshev));
	end
	if N_Chebyshev<=5
		Distance_in_zc=((Range_zc_Raman-0.5e-9)/(N_Chebyshev-1));
	end
end


zc_Raman_min=ZsnrEx_Raman(L);
		
figure (count_figures+40);
hold on
box on

d_min_Raman_range=zeros(N_Chebyshev,1);
Zc_values_d_min=zeros(N_Chebyshev, 1);
Minimum_error_zc_Raman=zeros(N_Chebyshev, 1);
Position_d_min=zeros(N_Chebyshev, 1);
Zc_found_dmin=zeros(N_Chebyshev, 1);

if Activate_Pick_d_min_Raman==0
%%%% This for loop would find you the points in dmin in a discrete range the one below allows you to pick
for ii=1:1:N_Chebyshev
            
%             Zc_values_Bistable(ii,1)=Pck_xx(ii,1); 
%           D_min(ii,1)=Pck_xx(ii,2);
			zc_Raman_range(ii, 1)=zc_Raman_min+(ii-1)*Distance_in_zc;  
			figure (count_figures+40);
			hold on
            plot(Set_Raman(:,4),  Set_Raman(:,1), '.b', 'Markersize', 3,'displayname','D_min Raman method'); 
			title('Finding points of d_m_i_n: Pick Vertically','fontsize',12)
			xlabel('Zc','fontsize',12) 
			ylabel('dmin','fontsize',12) 
			
            Minimum_error_d_min_Raman_dumb=MultiplierError*min(abs(Set_Raman(:,4)-zc_Raman_range(ii,1)));
            Minimum_error_d_min_Raman(ii,1)=Minimum_error_d_min_Raman_dumb;
        
            Position_d_min_dumb=find(abs(Set_Raman(:,4)-zc_Raman_range(ii,1))<=abs(Minimum_error_d_min_Raman_dumb),1, 'last');
            Position_d_min(ii,1)=Position_d_min_dumb; % this is the position of the vector element
            Zc_found_dmin(ii,1)=Set_Raman(Position_d_min_dumb,4);
            plot(Set_Raman(Position_d_min_dumb,4),  Set_Raman(Position_d_min_dumb,1),'Vk', 'Markersize', 5);
                
end  
Position_d_min_Raman=Position_d_min;
end	

if Activate_Pick_d_min_Raman==1     % this allows you to pick the points manually

for ii=1:1:N_Chebyshev
	
            plot(Set_Raman(:,4),  Set_Raman(:,1), '.b', 'Markersize', 3, 'displayname','D_min Raman method'); 
			title('Finding points of d_m_i_n: Pick Vertically','fontsize',12)
			xlabel('Zc','fontsize',12) 
			ylabel('dmin','fontsize',12) 
			[x_Raman,y_Raman]=ginput(1);		%%% x is zc and y is dmin 
			Pck_Raman=[x_Raman , y_Raman];
            
            d_min_Raman_range(ii,1)=Pck_Raman(1,2);   
			Zc_values_d_min(ii, 1)=Pck_Raman(1,1);  

			
            Minimum_error_zc_Raman_dumb=MultiplierError*min(abs(Set_Raman(:,4)-Zc_values_d_min(ii,1)));
            Minimum_error_zc_Raman(ii,1)=Minimum_error_zc_Raman_dumb;
        
            Position_zc_dumb=find(abs(Set_Raman(:,4)-Zc_values_d_min(ii,1))<=abs(Minimum_error_zc_Raman_dumb),1, 'last');
            Position_d_min(ii,1)=Position_zc_dumb; % this is the position of the vector element
            Zc_found_dmin(ii,1)=Set_Raman(Position_zc_dumb,4);
			hold on
            plot(Set_Raman(Position_zc_dumb,4),  Set_Raman(Position_zc_dumb,1),'Vk', 'Markersize', 5)
                
end  
end



