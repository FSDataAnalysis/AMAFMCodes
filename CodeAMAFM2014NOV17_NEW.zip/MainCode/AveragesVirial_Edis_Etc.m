% S Santos 2014 Sept #
% This file does statistics with the elastic modulus

load NumberOfFiles_2.mat

Adhesion_M=[];
Edis_crop_M=[];
Edis_M=[];
Virial_M=[];
Edis_adhesion_M=[];
Virial_adhesion_M=[];

for ii=1:c_mine_2
  
        strFileSpec = sprintf( 'Numerical_data%u', ii );
        load ( strFileSpec )
        
        Adhesion_M=cat(1, Adhesion_M,  F_adhesion);
        Edis_crop_M=cat(1, Edis_crop_M,  Edis_max_croped);
        Edis_M=cat(1, Edis_M,  Edis_max_notcropped);
        Virial_M=cat(1, Virial_M,  Virial_Fts_max);
        Edis_adhesion_M=cat(1, Edis_adhesion_M, E_dis_at_adhesion);
        Virial_adhesion_M=cat(1,Virial_adhesion_M, Virial_at_adhesion);
        
end


Mean_Adhesion_M=mean(Adhesion_M);
SD_Adhesion_M=std(Adhesion_M);

Mean_Edis_crop_M=mean(Edis_crop_M);
SD_Edis_crop_M=std(Edis_crop_M);

Mean_Virial_M=mean(Virial_M);
SD_Virial_M=std(Virial_M);

Mean_Edis_adhesion_M=mean(Edis_adhesion_M);
SD_Edis_adhesion_M=std(Edis_adhesion_M);

Mean_Virial_adhesion_M=mean(Virial_adhesion_M);
SD_Virial_adhesion_M=std(Virial_adhesion_M);

