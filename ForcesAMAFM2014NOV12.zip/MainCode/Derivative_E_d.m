

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Derivative_points=1;


%%%%  derivative energy %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Derivative_points=10;
    Differential_energy_norm=Edis_norm_ss(2:Derivative_points:end)-Edis_norm_ss(1:Derivative_points:end-1);
	Differential_energy_norm_crop=Edis_norm_crop_ss(2:Derivative_points:end)-Edis_norm_crop_ss(1:Derivative_points:end-1);
% 	 
 	Differential_Amplitude=A_norm(2:Derivative_points:end)-A_norm(1:Derivative_points:end-1);
 	Differential_Amplitude_crop=A_norm_crop(2:Derivative_points:end)-A_norm_crop(1:Derivative_points:end-1);
	
	Differential_dmin=(D_M_ZEROED(2:Derivative_points:end)-D_M_ZEROED(1:Derivative_points:end-1));
	Differential_dmin_norm=Differential_dmin/abs(min(D_M_ZEROED));

	Differential_crop_dmin=(D_M_ZEROED_CROP(2:Derivative_points:end)-D_M_ZEROED_CROP(1:Derivative_points:end-1));
	Differential_crop_dmin_norm=Differential_crop_dmin/abs(min(D_M_ZEROED_CROP));
		
	
	Derivative_norm=Differential_energy_norm./Differential_dmin_norm;
	Derivative_norm_crop=Differential_energy_norm_crop./Differential_crop_dmin_norm;

	Derivative_norm_A=Differential_energy_norm./Differential_Amplitude;
	Derivative_norm_crop_A=Differential_energy_norm_crop./Differential_Amplitude_crop;
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
	


% 	%%%%%%%% Get rid of infs, nans and zeros %%%%%%%%
% 	DUMMY_YY=zeros(length(Derivative_norm));
% 	DUMMY_XX=zeros(length(D_M_ZEROED(1:end-1)));
% 	DUMMY_YY=Derivative_norm;
% 	DUMMY_XX=D_M_ZEROED(1:end-1);
% 
% 	GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
% 	Derivative_norm_real=DUMMY_YY_real;
% 	d_m_real=DUMMY_XX_real;
% 	%%%%%% sorting %%%%%%%%
% 	
% 	vector_1=zeros(length(d_m_real));
% 	vector_2=zeros(length(Derivative_norm_real));
% 	vector_1=d_m_real;
% 	vector_2=Derivative_norm_real;
% 	Sort_sets_descending;
% 	d_m_real_sorted=vector_1;
% 	Derivative_norm_real_sorted=vector_2;
% 	
% 	
% 	%%%%%%%%  CROPED DATA: Get rid of infs, nans and zeros %%%%%%%%
% 	DUMMY_YY=zeros(length(Derivative_norm_crop));
% 	DUMMY_XX=zeros(length(D_M_ZEROED_CROP(1:end-1)));
% 	DUMMY_YY=Derivative_norm_crop;
% 	DUMMY_XX=D_M_ZEROED_CROP(1:end-1);
% 
% 	GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
% 	Derivative_norm_real_crop=DUMMY_YY_real;
% 	d_m_real_crop=DUMMY_XX_real;
% 	%%%%%% sorting %%%%%%%%
% 	vector_1=zeros(length(d_m_real_crop));
% 	vector_2=zeros(length(Derivative_norm_real_crop));
% 	vector_1=d_m_real_crop;
% 	vector_2=Derivative_norm_real_crop;
% 	Sort_sets_descending;
% 	d_m_real_crop_sorted=vector_1;
% 	Derivative_norm_real_crop_sorted=vector_2;
% 	
% 	
% 	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 	
% 	
% 	Derivative_norm_real_sorted_ss=smooth(Derivative_norm_real_sorted,ss_Derivative,'rloess');
% 	Derivative_norm_real_crop_sorted_ss=smooth(Derivative_norm_real_crop_sorted,ss_Derivative_crop,'rloess');
% 	
% 	%%%%%%%%%%% Find extrema %%%%%%%%%%%%%%%%%%%%

	Der_ss1=smooth(Derivative_norm,0.04,'rloess');
 	Der_ss1_crop=smooth(Derivative_norm_crop,0.1,'rloess');
% 	
 	Der_real_max=max(Der_ss1_crop);
 	Der_real_min=min(Der_ss1_crop);
	if (abs(Der_real_min)>abs(Der_real_max))
		Maxima_Der=Der_real_min;
		Der_Normalise=abs(Der_real_min);
	else
		Maxima_Der=Der_real_max;
		Der_Normalise=abs(Der_real_max);
	end
	%%%%%% ALl curve %%%%
	Der_real_max_T=max(Der_ss1);
	Der_real_min_T=min(Der_ss1);
	if (abs(Der_real_min_T)>abs(Der_real_max_T))
		Maxima_Der_T=Der_real_min_T;
		Der_Normalise_T=abs(Der_real_min_T);
	else
		Maxima_Der_T=Der_real_max_T;
		Der_Normalise_T=abs(Der_real_max_T);
	end
	
	
	%%% Amplitude %%%%
	Der_ss1_A=smooth(Derivative_norm_A,0.04,'rloess');
 	Der_ss1_crop_A=smooth(Derivative_norm_crop_A,0.1,'rloess');
% 	
 	Der_real_max_A=max(Der_ss1_crop_A);
 	Der_real_min_A=min(Der_ss1_crop_A);
	if (abs(Der_real_min_A)>abs(Der_real_max_A))
		Maxima_Der_A=Der_real_min_A;
		Der_Normalise_A=abs(Der_real_min_A);
	else
		Maxima_Der_A=Der_real_max_A;
		Der_Normalise_A=abs(Der_real_max_A);
	end
	%%%%%% ALl curve %%%%
	Der_real_max_T_A=max(Der_ss1_A);
	Der_real_min_T_A=min(Der_ss1_A);
	if (abs(Der_real_min_T_A)>abs(Der_real_max_T_A))
		Maxima_Der_T_A=Der_real_min_T_A;
		Der_Normalise_T_A=abs(Der_real_min_T_A);
	else
		Maxima_Der_T_A=Der_real_max_T_A;
		Der_Normalise_T_A=abs(Der_real_max_T_A);
	end
	
	
	
% 	Derivative_norm_real_sorted_ss_norm=Derivative_norm_real_sorted_ss/Der_Normalise_T;
% 	Derivative_norm_real_crop_sorted_ss_norm=Derivative_norm_real_crop_sorted_ss/Der_Normalise;
	
% 	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	figure (count_figures+64)
	hold on   
	box on
	%plot(D_M_ZEROED(1:end-1), Derivative_norm/Der_Normalise_T,'.k','Markersize',M_size, 'displayname','Check for raw data');
	title('Edis derivative versus dmin','fontsize',12)
	xlabel('dmin','fontsize',14) 
	ylabel('Normalised Edis Derivative','fontsize',14)
	plot(D_M_ZEROED(1:Derivative_points:end-1),Derivative_norm/Der_Normalise_T,'.m','Markersize',M_size, 'displayname','Energy derivative Normalised:raw');
	plot(D_M_ZEROED_CROP(1:Derivative_points: end-1), Derivative_norm_crop/Der_Normalise,'.k','Markersize',M_size, 'displayname','Energy derivative Normalised:croped');
	
	%% smooth
	plot(D_M_ZEROED(1:Derivative_points:end-1),Der_ss1/Der_Normalise_T,'.b','Markersize',M_size, 'displayname','Energy derivative Normalised:smooth');
	plot(D_M_ZEROED_CROP(1:Derivative_points: end-1), Der_ss1_crop/Der_Normalise,'.b','Markersize',M_size, 'displayname','Energy derivative Normalised:Smooth croped');
	%% Energies 
	plot(D_M_ZEROED, Edis_norm_ss,'.g','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Smooth');  % smooth
	plot(D_M_ZEROED_CROP, Edis_norm_crop_ss,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped:Smooth');  % smooth
	
	
	%plot(d_m_real_sorted,Derivative_norm_real_sorted_ss_norm ,'.g','Markersize',M_size, 'displayname','Energy derivative Normalised:smooth');
	%plot(d_m_real_crop_sorted,Derivative_norm_real_crop_sorted_ss_norm ,'.c','Markersize',M_size, 'displayname','Energy derivative Normalised dE*/dA*:smooth');
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	if Sader_Katan==1
		
		hold on
		plot(d_min_crop_zeroed,Fts_S_K_cons_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		hold on
		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');

		axis([ min_d_plot  max_d_plot -1.2 1.2])
 		text(1e-9,0.8, ['Max. Deriv.(Croped): ' num2str(Maxima_Der)],'fontsize',12)
		text(1e-9,0.6, ['Max. Deriv.(Total): ' num2str(Maxima_Der_T)],'fontsize',12)
		text(1e-9,0.4, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
	else
		
		axis([ d_min(1) d_min(end)  0 1.2])
		text(1e-9,0.8, ['Max. Deriv.(Croped): ' num2str(Maxima_Der)],'fontsize',12)
		text(1e-9,0.6, ['Max. Deriv.(Total): ' num2str(Maxima_Der_T)],'fontsize',12)
	end

	






% 
% 
% 
% 
% Edis_ss_r=smooth(Edis,ss_derivative_dmin,'rloess');
% Edis_max_T_r=max(Edis_ss_r);
% Edis_norm_ss_r=Edis_ss_r/Edis_max_T_r;
% derivative_1=(Edis_norm_ss_r(2:Derivative_points:end)-Edis_norm_ss_r(1:Derivative_points:end-1));
% derivative_1_raw=(Edis_norm_ss_r(2:end)-Edis_norm_ss_r(1:end-1));
% derivative_2=-(D_M_ZEROED(2:Derivative_points:end)-D_M_ZEROED(1:Derivative_points:end-1));
% derivative_2_raw=-(D_M_ZEROED(2:end)-D_M_ZEROED(1:end-1));
% derivative_3=derivative_1./derivative_2;
% derivative_3_raw=derivative_1_raw./derivative_2_raw;
% d_D_M_ZEROED=D_M_ZEROED(1:end-1);
% d_D_M_ZEROED_r=d_D_M_ZEROED(1:Derivative_points:end);
% d_D_M_ZEROED_r_raw=d_D_M_ZEROED;
% %%%%%%% Crop %%%%%%%%%%%%%%%%%%%%
% 
% Edis_ss_r_crop=smooth(Edis_crop,ss_derivative_dmin,'rloess');
% Edis_max_T_r_crop=max(Edis_ss_r_crop);
% Edis_norm_ss_r_crop=Edis_ss_r_crop/Edis_max_T_r_crop;
% derivative_1_crop=(Edis_norm_ss_r_crop(2:Derivative_points:end)-Edis_norm_ss_r_crop(1:Derivative_points:end-1));
% derivative_1_raw_crop=(Edis_norm_ss_r_crop(2:end)-Edis_norm_ss_r_crop(1:end-1));
% derivative_2_crop=-(D_M_ZEROED_CROP(2:Derivative_points:end)-D_M_ZEROED_CROP(1:Derivative_points:end-1));
% derivative_2_raw_crop=-(D_M_ZEROED_CROP(2:end)-D_M_ZEROED_CROP(1:end-1));
% derivative_3_crop=derivative_1_crop./derivative_2_crop;
% derivative_3_raw_crop=derivative_1_raw_crop./derivative_2_raw_crop;
% d_D_M_ZEROED_crop=D_M_ZEROED_CROP(1:end-1);
% d_D_M_ZEROED_r_crop=d_D_M_ZEROED_crop(1:Derivative_points:end);
% d_D_M_ZEROED_r_raw_crop=d_D_M_ZEROED_crop;
% 
% %%%%%%%%%%%%%%%%
% 
% figure (65)
% hold on
% box on
% plot(D_M_ZEROED,Edis/Edis_max_T_r ,'.m','Markersize',M_size, 'displayname','Energy Dissipated Normalised (dmin):Smooth');  % smooth
% plot(D_M_ZEROED, Edis_norm_ss_r,'.g','Markersize',M_size, 'displayname','Energy Dissipated Normalised (dmin):Smooth');  % smooth
% %%% crop
% plot(D_M_ZEROED_CROP,Edis_crop/Edis_max_T_r_crop ,'.m','Markersize',M_size, 'displayname','Energy Dissipated Normalised (dmin):Smooth:crop');  % smooth
% plot(D_M_ZEROED_CROP, Edis_norm_ss_r_crop,'.g','Markersize',M_size, 'displayname','Energy Dissipated Normalised (dmin):Smooth:crop');  % smooth
% 
% %%% remove %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% DUMMY_YY=zeros(length(derivative_3));
% DUMMY_XX=zeros(length(d_D_M_ZEROED_r));
% DUMMY_YY=derivative_3;
% DUMMY_XX=d_D_M_ZEROED_r;
% 
% GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
% derivative_3_sorted=DUMMY_YY_real;
% d_D_M_ZEROED_r_sorted=DUMMY_XX_real;
% 	
% %%%%%%% sort descending %%%%%%%
% 	
% vector_1=zeros(length(d_D_M_ZEROED_r_sorted));
% vector_2=zeros(length(derivative_3_sorted));
% vector_1=d_D_M_ZEROED_r_sorted;
% vector_2=derivative_3_sorted;
% Sort_sets_descending;
% d_D_M_ZEROED_r_sorted_s=vector_1;
% derivative_3_sorted_s=vector_2;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 	
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% crop %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DUMMY_YY=zeros(length(derivative_3_crop));
% DUMMY_XX=zeros(length(d_D_M_ZEROED_r_crop));
% DUMMY_YY=derivative_3_crop;
% DUMMY_XX=d_D_M_ZEROED_r_crop;
% 
% GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
% derivative_3_sorted_crop=DUMMY_YY_real;
% d_D_M_ZEROED_r_sorted_crop=DUMMY_XX_real;
% 	
% %%%%%%% sort descending %%%%%%%
% 	
% vector_1=zeros(length(d_D_M_ZEROED_r_sorted_crop));
% vector_2=zeros(length(derivative_3_sorted_crop));
% vector_1=d_D_M_ZEROED_r_sorted_crop;
% vector_2=derivative_3_sorted_crop;
% Sort_sets_descending;
% d_D_M_ZEROED_r_sorted_s_crop=vector_1;
% derivative_3_sorted_s_crop=vector_2;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% 	
% derivative_3_sorted_s_ss=smooth(derivative_3_sorted_s, ss_derivative_dmin, 'rloess');
% derivative_3_sorted_s_ss_crop=smooth(derivative_3_sorted_s_crop, ss_derivative_dmin, 'rloess');
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Der_real_max_dmin_T_crop=max(derivative_3_sorted_s_ss_crop(floor(0.05*(length(derivative_3_sorted_s_ss_crop))):floor(0.9*(length(derivative_3_sorted_s_ss_crop)))));
% Der_real_min_dmin_T_crop=min(derivative_3_sorted_s_ss_crop(floor(0.05*(length(derivative_3_sorted_s_ss_crop))):floor(0.9*(length(derivative_3_sorted_s_ss_crop)))));
% if (abs(Der_real_min_dmin_T_crop)>abs(Der_real_max_dmin_T_crop))
% 	Maxima_Der_dmin_T_crop=Der_real_min_dmin_T_crop;
% 	Der_Normalise_dmin_T_crop=abs(Der_real_min_dmin_T_crop);
% else
% 	Maxima_Der_dmin_T_crop=Der_real_max_dmin_T_crop;
% 	Der_Normalise_dmin_T_crop=abs(Der_real_max_dmin_T_crop);
% end
% 	%%%%%% ALl curve %%%%
% Der_real_max_dmin_T=max(derivative_3_sorted_s_ss(floor(0.05*(length(derivative_3_sorted_s_ss))):floor(0.9*(length(derivative_3_sorted_s_ss)))));
% Der_real_min_dmin_T=min(derivative_3_sorted_s_ss(floor(0.05*(length(derivative_3_sorted_s_ss))):floor(0.9*(length(derivative_3_sorted_s_ss)))));
% if (abs(Der_real_min_dmin_T)>abs(Der_real_max_dmin_T))
% 	Maxima_Der_dmin_T=Der_real_min_dmin_T;
% 	Der_Normalise_dmin_T=abs(Der_real_min_dmin_T);
% else
% 	Maxima_Der_dmin_T=Der_real_max_dmin_T;
% 	Der_Normalise_dmin_T=abs(Der_real_max_dmin_T);
% end
% 	
% Derivative_norm_real_sorted_ss_norm_dmin=derivative_3_sorted_s_ss/Der_Normalise_dmin_T;
% Derivative_norm_real_crop_sorted_ss_norm_dmin=derivative_3_sorted_s_ss_crop/Der_Normalise_dmin_T_crop;
% 	
% %%%%%%%%%%%%%%%%%%%%%%%%%
% 
% figure (65)
% hold on
% plot(d_D_M_ZEROED_r_sorted_s, derivative_3_sorted_s/Der_Normalise_dmin_T,'.k','Markersize',M_size, 'displayname','Energy derivative Normalised (dmin) : raw');  % smooth
% plot(d_D_M_ZEROED_r_sorted_s, Derivative_norm_real_sorted_ss_norm_dmin,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised (dmin):Smooth');  % smooth
% %%% crop %%%%%%%%%
% plot(d_D_M_ZEROED_r_sorted_s_crop, derivative_3_sorted_s_crop/Der_Normalise_dmin_T_crop,'.k','Markersize',M_size,'displayname', 'Energy derivative Normalised (dmin) : raw:crop');  % smooth
% plot(d_D_M_ZEROED_r_sorted_s_crop, Derivative_norm_real_crop_sorted_ss_norm_dmin,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised (dmin):Smooth:crop');   % smooth
% 
% if Sader_Katan==1
% 		
% 		hold on
% 		plot(d_min_crop_zeroed,Fts_S_K_cons_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
% 		hold on
% 		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');
% 
% 		axis([ min_d_plot  max_d_plot -1.2 1.2])
% 		text(1e-9,0.8, ['Max Der (Croped): ' num2str(Der_Normalise_dmin_T_crop)],'fontsize',12)
% 		text(1e-9,0.6, ['Max Der (Total): ' num2str(Der_Normalise_dmin_T)],'fontsize',12)
% 		text(1e-9,0.4, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
% 	else
% 		
% 		axis([ min_d_plot  max_d_plot -1.2 1.2])
% 		text(1e-9,0.8, ['Max Der (Croped): ' num2str(Der_Normalise_dmin_T_crop)],'fontsize',12)
% 		text(1e-9,0.6, ['Max Der (Total): ' num2str(Der_Normalise_dmin_T)],'fontsize',12)
% end
% 
% 
% 
