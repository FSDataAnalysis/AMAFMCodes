% % % 
%  	close all;
% 	clear all;
% 	load example
% 	

if Smooth_raw_data==1
		
	if Sader_Katan==1
		D_shift=D_min_zero_found;
		Fts_S_K_cons_norm=Fts_cons_crop_raw/abs(F_adhesion);
		Fts_S_K_cons_norm_ss=Fts_cons_crop_sorted_ss/abs(F_adhesion);
		min_d_plot=d_min_crop_sorted_zeroed(end)-4e-9;
		max_d_plot=d_min_crop_sorted_zeroed(1);
		
		D_M_ZEROED_CROP=d_min_crop-D_shift;
		D_M_ZEROED=d_min-D_shift;
		
		D_M_ZEROED_CROP_d=d_min_crop_d-D_shift;
		D_M_ZEROED_d=d_min_d-D_shift;
	else    %% This is if we do not have force to calculate Fa or if there is no simulation
		D_shift=0;
	end
		
	ss_Edis=0.01; 
	ss_Virial=0.02;
	ss_Derivative=0.02;
	ss_Derivative_crop=0.02; 
	Derivative_points=1;  %% How many points in dmin to calculate derivative Fig. ss_derivative_dmin
	ss_angle_cons=0.01;
	ss_phase=0.02;
	ss_Edis_Ph=0.01;
	ss_Edis_Ph_crop=0.01;
	ss_Damp_Coeff=0.01;
	ss_OMEGA=0.02;
	ss_phase_diff=0.08;
	ss_amplitude_d=0.01; % Figure in qunatification Figure 70


	%%%%%%%% Prepare vectors %%%%%%%%%%%%%%%%%%%%
	A_norm=AmEx/A0;
	A_norm_crop=A_norm(Position_Zc(2,1):Position_Zc(1,1));
	
		
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Virial  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	

 
	
% if plot_data_processing_figures==1   %% VIRIAL 
	

if Virial_plot==1||plot_data_processing_figures==1
    
	Virial_Fts=k/2*AmEx.*AmEx*(1-OMEGA^2)-A0.*AmEx/2/Q.*cosine_angle_EX;
    Virial_Fts_crop=Virial_Fts(Position_Zc(2,1):Position_Zc(1,1));
	%%% As dmin %%
% 	A_norm_d=AmEx_d/A0;
% 	A_norm_crop_d=AmEx_crop_d/A0;
% 	Virial_Fts_d=k/2*AmEx_d.*AmEx_d*(1-OMEGA^2)-A0.*AmEx_d/2/Q.*cosine_angle_EX_d;
%     Virial_Fts_crop_d=k/2*AmEx_crop_d.*AmEx_crop_d*(1-OMEGA^2)-A0.*AmEx_crop_d/2/Q.*cosine_angle_EX_crop_d;
	%%% As A/A0 %%
% 	A_norm_A=AmEx_A/A0;
% 	A_norm_crop_A=AmEx_crop_A/A0;
% 	Virial_Fts_A=k/2*AmEx_A.*AmEx_A*(1-OMEGA^2)-A0.*AmEx_A/2/Q.*cosine_angle_EX_A;
%   Virial_Fts_crop_A=k/2*AmEx_crop_A.*AmEx_crop_A*(1-OMEGA^2)-A0.*AmEx_crop_A/2/Q.*cosine_angle_EX_crop_A;
% 	
	
	%%%% Smoothen virial %%%%%%
	
    Virial_Fts_ss=smooth(Virial_Fts,ss_Virial,'rloess');  %% 
	Virial_Fts_crop_ss=smooth(Virial_Fts_crop,ss_Virial,'rloess');  %% 
    Virial_Fts_max=abs(max(Virial_Fts_ss));
	
% 	Virial_Fts_A_ss=smooth(Virial_Fts_A,ss_Virial,'rloess');  %% 
%   Virial_Fts_crop_A_ss=smooth(Virial_Fts_crop_A,ss_Virial,'rloess');  %% 
 	
	%%%%%%%%%%%%%%%%%%  Normalise Virial %%%%%%%%%%%%%%%%%%%%%%%%%%%
    Virial_Fts_norm=Virial_Fts/Virial_Fts_max;
	Virial_Fts_norm_crop=Virial_Fts_norm(Position_Zc(2,1):Position_Zc(1,1));
	
	Virial_Fts_ss_norm=Virial_Fts_ss/Virial_Fts_max;
	Virial_Fts_crop_ss_norm=Virial_Fts_crop_ss/Virial_Fts_max;
 
end

if plot_data_processing_figures==1   %% VIRIAL 
% % 	%%% arranged in terms of dmin and already smoothened %%%%%%%%
% % 	Virial_Fts_d_ss_norm=Virial_Fts_d_ss/Virial_Fts_max;
% % 	Virial_Fts_d_ss_norm_crop=Virial_Fts_crop_d_ss/Virial_Fts_max;
% % 	%% As A/A0
% % 	Virial_Fts_A_ss_norm=Virial_Fts_A_ss/Virial_Fts_max;
% % 	Virial_Fts_A_ss_norm_crop=Virial_Fts_crop_A_ss/Virial_Fts_max;

   
    
	figure (count_figures+20)
    hold on
	box on
    plot(D_M_ZEROED, Virial_Fts_norm,'.m','Markersize',M_size, 'displayname','Virial_Normalised');
	plot(D_M_ZEROED_CROP, Virial_Fts_norm_crop,'.k','Markersize',M_size, 'displayname','Virial_Normalised:crop');
	title(' Virial versus Dmin: raw','fontsize',12)
	xlabel('dmin','fontsize',14) 
	ylabel('Normalised Virial','fontsize',14)
	plot(D_M_ZEROED, Virial_Fts_ss_norm,'.g','Markersize',M_size, 'displayname','Virial_Normalised:smoothened');
	plot(D_M_ZEROED_CROP, Virial_Fts_crop_ss_norm,'.c','Markersize',M_size, 'displayname','Virial_Normalised:crop:smoothened');
	
	%%% Smoothened %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	if Sader_Katan==1
		
		hold on
		plot(D_M_ZEROED_CROP,Fts_S_K_cons_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		hold on
		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');
	end
	
	axis([ min_d_plot  max_d_plot -2 2])
    text(0,1.2, ['Max Virial:' num2str(Virial_Fts_max), ' Nm'],'fontsize',12)
	text(0,0.4, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)

% 	if Virial_Distances==1
% 		Find_Virial_Distance;		%% This finds the distance from 5% of positive virial until it returns to 0
% 	end
	%%%%%%% Virial As A/A0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
    figure (count_figures+21)
	hold on
	box on
	plot(A_norm, Virial_Fts_norm,'.k','Markersize',M_size, 'displayname','Virial_Normalised');
	plot(A_norm_crop, Virial_Fts_norm_crop,'.r','Markersize',M_size, 'displayname','Virial_Normalised:crop');
	title(' Virial versus A/A0: raw','fontsize',12);
	xlabel('A/A0','fontsize',14); 
	ylabel('Normalised Virial','fontsize',14);
	
	%%%%% Smoothen %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 	plot(A_norm, Virial_Fts_ss_norm,'.c','Markersize',M_size, 'displayname','Virial_Normalised:smooth');
 	plot(A_norm_crop, Virial_Fts_crop_ss_norm,'.b','Markersize',M_size, 'displayname','Virial_Normalised:crop:smooth');
	
	axis([ min(A_norm)  1 min(Virial_Fts_ss_norm) 1.2])
	text(0.95,-1, ['Max Virial:' num2str(Virial_Fts_max), 'Nm'],'fontsize',12)
	
	
end
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
    %%%% Energy dissipation cleveland ========================================= %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
	if use_real_Edis==1
		Edis=Edis_T;
	else
		Edis=pi*k.*AmEx.*(A_DRIVE.*sine_angle_EX-(OMEGA/Q).*AmEx)*6.24e18;
% 		Edis_d=pi*k.*AmEx_d.*(A_DRIVE.*sine_angle_EX_d-(OMEGA/Q).*AmEx_d)*6.24e18;
% 		Edis_A=pi*k.*AmEx_A.*(A_DRIVE.*sine_angle_EX_A-(OMEGA/Q).*AmEx_A)*6.24e18;
		
		Edis_crop=pi*k*AmEx_crop.*(A_DRIVE.*sine_angle_EX_crop-(OMEGA/Q).*AmEx_crop)*6.24e18;
% 		Edis_crop_d=pi*k*AmEx_crop_d.*(A_DRIVE.*sine_angle_EX_crop_d-(OMEGA/Q).*AmEx_crop_d)*6.24e18;
% 		Edis_crop_A=pi*k*AmEx_crop_A.*(A_DRIVE.*sine_angle_EX_crop_A-(OMEGA/Q).*AmEx_crop_A)*6.24e18;
	end

	
	Edis_crop_ss=smooth(Edis_crop,ss_Edis,'rloess');  %% 
	Edis_ss=smooth(Edis,ss_Edis,'rloess');
 	Edis_max=max(Edis_crop_ss);   %% maximum energy in the croped section 
	Edis_max_T=max(Edis_ss);    %%% Whole curve
	
	
	%%% Normalise energies   
 	Edis_norm=Edis/Edis_max_T;
%   Edis_d_norm=Edis_d/Edis_max_T;
% 	Edis_A_norm=Edis_A/Edis_max_T;
	%%%% croped 
 	Edis_crop_norm=Edis_crop/Edis_max;
%   Edis_crop_d_norm=Edis_crop_d/Edis_max;
% 	Edis_crop_A_norm=Edis_crop_A/Edis_max;
	%%%% smoothened 
	
	%%%% Normalise energy %%%%%%%%%%%%%%%%
	
	Edis_norm_crop_ss=Edis_crop_ss/Edis_max;
	Edis_norm_ss=Edis_ss/Edis_max_T;
	
	
	figure (count_figures+50)
	hold on
	box on
	plot(D_M_ZEROED, Edis_norm,'.m','Markersize',M_size, 'displayname','Energy Dissipated Normalised');   %% raw
	plot(D_M_ZEROED_CROP, Edis_crop_norm,'.k','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped');  % raw
	title('Edis versus Dmin','fontsize',12)
	xlabel('dmin','fontsize',14) 
	ylabel('Normalised Edis','fontsize',14)
	%%%% Smoothened %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	plot(D_M_ZEROED, Edis_norm_ss,'.g','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Smooth');  % smooth
	plot(D_M_ZEROED_CROP, Edis_norm_crop_ss,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped:Smooth');  % smooth
	
	if Sader_Katan==1
		
		hold on
		plot(d_min_crop_zeroed,Fts_S_K_cons_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		hold on
		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');

		axis([ min_d_plot  max_d_plot -1.2 1.2])
		text(1e-9,0.8, ['Max Edis (Croped): ' num2str(Edis_max), ' eV'],'fontsize',12)
		text(1e-9,0.6, ['Max Edis (Total): ' num2str(Edis_max_T), ' eV'],'fontsize',12)
		text(1e-9,0.4, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
	else
		
		axis([ min_d_plot  max_d_plot 0 1.2])
		text(1e-9,0.8, ['Max Edis (Croped): ' num2str(Edis_max), ' eV'],'fontsize',12)
		text(1e-9,0.6, ['Max Edis (Total): ' num2str(Edis_max_T), ' eV'],'fontsize',12)
	end

	figure (count_figures+51)
	hold on
	box on
	plot(A_norm, Edis_norm,'.k','Markersize',M_size, 'displayname','Energy Dissipated Normalised');
	plot(A_norm_crop, Edis_crop_norm,'.r','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped');
	text(0.7*max(A_norm),0.2, ['Max Edis: ' num2str(Edis_max_T), ' eV'],'fontsize',12)
	text(0.7*max(A_norm),0.6, ['Max Edis (crop): ' num2str(Edis_max), ' eV'],'fontsize',12)
	%%%% Smoothen %%%%%%
	plot(A_norm, Edis_norm_ss,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Cleveland');
	plot(A_norm_crop, Edis_norm_crop_ss,'.b','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped');
	
	title('Edis versus A/A0','fontsize',12)
	xlabel('A/A0','fontsize',14) 
	ylabel('Normalised Edis','fontsize',14)
	
	
	
	
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Conservative and dissipative phase %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
%%%%%% Smooth %%%%%
ANGLE_CONSERVATIVE_ss=smooth(ANGLE_CONSERVATIVE,ss_angle_cons,'rloess');  %%
ANGLE_CONSERVATIVE_crop_ss=smooth(ANGLE_CONSERVATIVE_crop,ss_angle_cons,'rloess');  %%

%%%%% Floor for conservattive from cyane, i.e. conservative croped %%%%%%%%%%%%%%%%%%
ANGLE_CONSERVATIVE_crop_ss_mean= mean(ANGLE_CONSERVATIVE_crop_ss(1:floor(0.08*length(ANGLE_CONSERVATIVE_crop_ss))));
Correct_angle_crop=ANGLE_CONSERVATIVE_crop_ss_mean-90;
ANGLE_CONSERVATIVE_ss_mean= mean(ANGLE_CONSERVATIVE_ss(1:floor(0.05*length(ANGLE_CONSERVATIVE_ss))));
Correct_angle=ANGLE_CONSERVATIVE_ss_mean-90;

%%%%%%%%
ANGLE_CONSERVATIVE=ANGLE_CONSERVATIVE-Correct_angle;
ANGLE_CONSERVATIVE_ss=ANGLE_CONSERVATIVE_ss-Correct_angle;
ANGLE_CONSERVATIVE_crop=ANGLE_CONSERVATIVE_crop-Correct_angle_crop;
ANGLE_CONSERVATIVE_crop_ss=ANGLE_CONSERVATIVE_crop_ss-Correct_angle_crop;
	

PhEx_ss=smooth(PhEx,ss_phase,'rloess'); 
PhEx_crop_ss=smooth(PhEx_crop,ss_phase,'rloess'); 


if plot_data_processing_figures==1
	
figure (count_figures+22)
hold on
box on


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

plot(D_M_ZEROED, ANGLE_CONSERVATIVE,'.m','Markersize',M_size, 'displayname','Conservative phase');
hold on
plot(D_M_ZEROED, ANGLE_CONSERVATIVE_ss,'.g','Markersize',M_size, 'displayname','Conservative phase:smooth');
plot(D_M_ZEROED_CROP,ANGLE_CONSERVATIVE_crop ,'.k','Markersize',M_size, 'displayname','Conservative:croped');
plot(D_M_ZEROED_CROP, ANGLE_CONSERVATIVE_crop_ss,'.c','Markersize',M_size, 'displayname','Conservative phase:croped:smooth');
hold on
plot(D_M_ZEROED, PhEx,'.r','Markersize',M_size, 'displayname','phase');
plot(D_M_ZEROED, PhEx_ss,'.b','Markersize',M_size, 'displayname','phase:smoothed');
plot(D_M_ZEROED_CROP, PhEx_crop,'.r','Markersize',M_size, 'displayname','phase');
plot(D_M_ZEROED_CROP, PhEx_crop_ss,'.b','Markersize',M_size, 'displayname','phase:smoothed:crop');
title('Conservative and dissipative phase branches:dmin','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Phase','fontsize',14)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure (count_figures+23)
hold on
box on
plot(A_norm, ANGLE_CONSERVATIVE,'.k','Markersize',M_size, 'displayname','Conservative phase');
plot(A_norm_crop, ANGLE_CONSERVATIVE_crop,'.c','Markersize',M_size, 'displayname','Conservative:croped');
plot(A_norm, PhEx,'.m','Markersize',M_size, 'displayname','phase');
plot(A_norm, PhEx_ss,'.g','Markersize',M_size, 'displayname','Phase:smooth');
plot(A_norm_crop, PhEx_crop,'.r','Markersize',M_size, 'displayname','phase:croped');
plot(A_norm_crop, PhEx_crop_ss,'.b','Markersize',M_size, 'displayname','Phase:Smooth:crop');
title('Conservative and dissipative phase branches:A/A0','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Phase','fontsize',14)

end

%%%%%% %%%% Phase difference and energy times phase difference %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% Phase difference %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Phase difference  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	



%%%%%% CORRECT THE PHASE TO 90 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Phase_dis_crop_ss_mean= mean(PhEx_crop_ss(1:floor(0.08*length(PhEx_crop_ss))));
Correct_phase_crop=Phase_dis_crop_ss_mean-90;
Phase_dis_ss_mean= mean(PhEx_ss(1:floor(0.05*length(PhEx_ss))));
Correct_phase=Phase_dis_ss_mean-90;

%%%%%%%%
PhEx_correct=PhEx-Correct_phase;
PhEx_correct_ss=PhEx_ss-Correct_phase;
PhEx_correct_crop=PhEx_crop-Correct_phase_crop;
PhEx_correct_crop_ss=PhEx_crop_ss-Correct_phase_crop;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% dmin full curve from dmin this is all smoothened %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Phase_difference=abs(ANGLE_CONSERVATIVE_ss-PhEx_correct_ss);
Phase_difference_ss=smooth(Phase_difference,ss_phase_diff,'rloess');  %ss_phase_diff_d

Phase_difference_max=abs(max(Phase_difference_ss));
Phase_difference_norm=Phase_difference/Phase_difference_max;
Phase_difference_norm_ss=Phase_difference_ss/Phase_difference_max;

%crop
Phase_difference_crop=abs(ANGLE_CONSERVATIVE_crop_ss-PhEx_correct_crop_ss);
Phase_difference_crop_ss=smooth(Phase_difference_crop,ss_phase_diff,'rloess');   % 

Phase_difference_max_crop=abs(max(Phase_difference_crop_ss));
Phase_difference_crop_norm=Phase_difference_crop/Phase_difference_max_crop;
Phase_difference_crop_norm_ss=Phase_difference_crop_ss/Phase_difference_max_crop;


%%%%%%%%%%%%%% Phase difference %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% zero angle at infinity %%%%%
%%%%% Floor for conservattive from cyane, i.e. conservative croped %%%%%%%%%%%%%%%%%%
Phase_difference_norm_ss_mean= mean(Phase_difference_norm_ss(1:floor(0.05*length(Phase_difference_norm_ss))));
Correct_angle_PD=Phase_difference_norm_ss_mean;
Phase_difference_norm_crop_ss_mean= mean(Phase_difference_crop_norm_ss(1:floor(0.08*length(Phase_difference_crop_norm_ss))));
Correct_angle_crop_PD=Phase_difference_norm_crop_ss_mean;
% 
% %%%%% Correct angles %%%%%%%%%%%%%%%%%%%%%%%%%%
Phase_difference_norm_r=Phase_difference_norm-Correct_angle_PD;
Phase_difference_norm_ss_r=Phase_difference_norm_ss-Correct_angle_PD;
max_PD=abs(max(Phase_difference_norm_ss_r));
Phase_difference_norm_r=Phase_difference_norm_r/max_PD;
Phase_difference_norm_ss_r=Phase_difference_norm_ss_r/max_PD;

Phase_difference_crop_norm_r=Phase_difference_crop_norm-Correct_angle_crop_PD;
Phase_difference_crop_norm_ss_r=Phase_difference_crop_norm_ss-Correct_angle_crop_PD;
max_PD_crop=abs(max(Phase_difference_crop_norm_ss_r));
Phase_difference_crop_norm_r=Phase_difference_crop_norm_r/max_PD_crop;
Phase_difference_crop_norm_ss_r=Phase_difference_crop_norm_ss_r/max_PD_crop;

%%%%%%%%%%%%%% Phase difference %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure (count_figures+52)
hold on
box on

%%%%%%%%%%
plot(D_M_ZEROED, Phase_difference_norm_r,'.m','Markersize',M_size, 'displayname','Phase difference');
hold on
plot(D_M_ZEROED,Phase_difference_norm_ss_r ,'.g','Markersize',M_size, 'displayname','Phase difference_r:smooth');
%%%% crop %%%%%
plot(D_M_ZEROED_CROP, Phase_difference_crop_norm_r ,'.k','Markersize',M_size, 'displayname','Phase difference:croped');
hold on
plot(D_M_ZEROED_CROP,Phase_difference_crop_norm_ss_r ,'.c','Markersize',M_size, 'displayname','Phase difference_r:croped: smooth');


if Sader_Katan==1
		
		hold on
		plot(d_min_crop_zeroed,Fts_S_K_cons_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		hold on
		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');

		axis([ min_d_plot  max_d_plot -1.2 1.2])
 		text(1e-9,1.0, ['Max PhxDiff (crop): ' num2str(Phase_difference_max_crop/max_PD_crop), '�'],'fontsize',12)
		text(1e-9,0.8, ['Max PhxDiff (Total): ' num2str(Phase_difference_max/max_PD), '�'],'fontsize',12)
		text(1e-9,0.6, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
	else
		
		axis([ d_min(1) d_min(end)  0 1.2])
		text(1e-9,0.9, ['Max PhxDiff (crop): ' num2str(Phase_difference_max_crop_d), '�'],'fontsize',12)
		text(1e-9,0.7, ['Max PhxDiff (Total): ' num2str(Phase_difference_max_d), '�'],'fontsize',12)
end


title('Phase difference dmin: raw','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Phase difference: Normalised','fontsize',14)

%%%%%%%%%%%%%%%

figure (count_figures+53)
hold on
box on

% Phase_difference_norm_ss=smooth(Phase_difference_norm_r_norm,ss_phase_diff_A_2,'rloess'); 
% Phase_difference_norm_crop_ss=smooth(Phase_difference_norm_crop_r_norm,ss_phase_diff_A,'rloess');
% Phase_difference_norm_ss_max=max(Phase_difference_norm_ss);
% Phase_difference_norm_crop_ss_max=max(Phase_difference_norm_crop_ss);

plot(A_norm, Phase_difference_norm_r,'.k','Markersize',M_size, 'displayname','Phase difference');
plot(A_norm_crop, Phase_difference_crop_norm_r,'.r','Markersize',M_size, 'displayname','Phase difference:croped');


plot(A_norm, Phase_difference_norm_ss_r,'.c','Markersize',M_size, 'displayname','Phase difference:Smooth');
plot(A_norm_crop,Phase_difference_crop_norm_ss_r,'.b','Markersize',M_size, 'displayname','Phase difference:croped:smooth');

text(0.95*max(A_norm),0.8, ['Max PhDiff (crop): ' num2str(Phase_difference_max_crop/max_PD_crop), '�'],'fontsize',12)
text(0.95*max(A_norm),0.6, ['Max PhDiff (Total): ' num2str(Phase_difference_max/max_PD), '�'],'fontsize',12)
title('Phase difference A/A0: raw','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Phase difference: Normalised','fontsize',14)
	

%%%%%% %%%% Energy times phase difference %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%
%% crop %%%%%%%%%%%%%%%%%%%%%
Phase_Energy_crop=Edis_crop_norm.*Phase_difference_crop_norm_r;
Phase_Energy_crop_ss=smooth(Phase_Energy_crop,ss_Edis_Ph_crop,'rloess');
Phase_Energy_crop_max=abs(max(Phase_Energy_crop_ss));

Phase_Energy_crop_norm=Phase_Energy_crop/Phase_Energy_crop_max;
Phase_Energy_crop_norm_ss=Phase_Energy_crop_ss/Phase_Energy_crop_max;


%% Full %%%%%%%%
Phase_Energy=Edis_norm.*Phase_difference_norm_r;
Phase_Energy_ss=smooth(Phase_Energy,ss_Edis_Ph,'rloess');
Phase_Energy_max=abs(max(Phase_Energy_ss));


Phase_Energy_norm=Phase_Energy/Phase_Energy_max;
Phase_Energy_norm_ss=Phase_Energy_ss/Phase_Energy_max;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


figure (count_figures+54)
hold on
box on
plot(D_M_ZEROED, Phase_Energy_norm,'.m','Markersize',M_size, 'displayname','Phase difference*Energy');
plot(D_M_ZEROED_CROP, Phase_Energy_crop_norm,'.k','Markersize',M_size, 'displayname','Phase difference*Energy:croped');


plot(D_M_ZEROED, Phase_Energy_norm_ss ,'.g','Markersize',M_size, 'displayname','Phase difference*Energy_r');
plot(D_M_ZEROED_CROP,Phase_Energy_crop_norm_ss ,'.c','Markersize',M_size, 'displayname','Phase difference*Energy:croped_r');

if Sader_Katan==1
		
		hold on
		plot(d_min_crop_zeroed,Fts_S_K_cons_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		hold on
		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');

		axis([ min_d_plot  max_d_plot -1.2 1.2])
 		text(1e-9,1.0, ['Max EdisPh: ' num2str(Phase_Energy_max), ' eV x �'],'fontsize',12)
		text(1e-9,0.8, ['Max EdisPh (Crop): ' num2str(Phase_Energy_crop_max), ' eV x �'],'fontsize',12)
		text(1e-9,0.6, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
	else
		
		axis([ d_min(1) d_min(end)  0 1.2])
		text(1e-9,0.9, ['Max EdisPh: ' num2str(Phase_Energy_max), ' eV x �'],'fontsize',12)
		text(1e-9,0.7, ['Max EdisPh (Crop): ' num2str(Phase_Energy_crop_max), ' eV x �'],'fontsize',12)
end



title('Phase difference*Energy dmin','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Phase difference*Energy: Normalised','fontsize',14)


%%%%% A/A0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure (count_figures+55)
hold on
box on 
plot(A_norm, Phase_Energy_norm,'.m','Markersize',M_size, 'displayname','Phase difference*Energy');
plot(A_norm_crop, Phase_Energy_crop_norm,'.k','Markersize',M_size, 'displayname','Phase difference*Energy:croped');

%%% Smooth %%%%
plot(A_norm, Phase_Energy_norm_ss,'.g','Markersize',M_size, 'displayname','Phase difference:Smooth');
plot(A_norm_crop, Phase_Energy_crop_norm_ss,'.c','Markersize',M_size, 'displayname','Phase difference:croped:smooth');

text(min(A_norm), 0.9, ['Max EdisPh: ' num2str(Phase_Energy_max), ' eV x �'],'fontsize',12);
text(min(A_norm),0.7, ['Max EdisPh (Crop): ' num2str(Phase_Energy_crop_max), ' eV x �'],'fontsize',12);
title('Phase difference*Energy A/A0','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Phase difference*Energy: Normalised','fontsize',14)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% Damping_coefficient %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%% Smoothing and finding max for normalization %%%%%%%%

Damping_coefficient_ss=smooth(Damping_coefficient,ss_Damp_Coeff,'rloess');
Damping_coefficient_crop_ss=smooth(Damping_coefficient_crop,ss_Damp_Coeff,'rloess');
Damping_coefficient_ss_max=max(Damping_coefficient_ss);
Damping_coefficient_crop_ss_max=max(Damping_coefficient_crop_ss);

%%%%% getting to zero %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Damping_coefficient_ss_mean=mean(Damping_coefficient_ss(1:floor(0.05*length(Damping_coefficient_ss))));
Correct_Damp=Damping_coefficient_ss_mean;
Damping_coefficient_crop_ss_mean=mean(Damping_coefficient_crop_ss(1:floor(0.08*length(Damping_coefficient_crop_ss))));
Correct_Damp_crop=Damping_coefficient_crop_ss_mean;

%%%%% Correcting %%%%%%%%%
Damping_coefficient_r=Damping_coefficient-Correct_Damp;
Damping_coefficient_crop_r=Damping_coefficient_crop-Correct_Damp_crop;
Damping_coefficient_ss_r=Damping_coefficient_ss-Correct_Damp;
Damping_coefficient_crop_ss_r=Damping_coefficient_crop_ss-Correct_Damp_crop;
%%%%
Damping_coefficient_ss_r_max=abs(max(Damping_coefficient_ss_r));
Damping_coefficient_crop_ss_r_max=abs(max(Damping_coefficient_crop_ss_r));

%%% Normalizing %%%%%%%%
Damping_coefficient_r_norm=Damping_coefficient_r/Damping_coefficient_ss_r_max;
Damping_coefficient_crop_r_norm=Damping_coefficient_crop_r/Damping_coefficient_crop_ss_r_max;
Damping_coefficient_ss_r_norm=Damping_coefficient_ss_r/Damping_coefficient_ss_r_max;
Damping_coefficient_crop_ss_r_norm=Damping_coefficient_crop_ss_r/Damping_coefficient_crop_ss_r_max;

%%%%%%%%%%%%%%%%%

%%% Plots %%%%%%%%

figure (count_figures+56)
hold on
box on
plot(D_M_ZEROED, Damping_coefficient_r_norm,'.m','Markersize',M_size, 'displayname','Damping coefficient');
plot(D_M_ZEROED_CROP, Damping_coefficient_crop_r_norm,'.k','Markersize',M_size, 'displayname','Damping coefficient:croped');
plot(D_M_ZEROED, Damping_coefficient_ss_r_norm,'.g','Markersize',M_size, 'displayname','Damping coefficient');
plot(D_M_ZEROED_CROP, Damping_coefficient_crop_ss_r_norm,'.c','Markersize',M_size, 'displayname','Damping coefficient:croped');

if Sader_Katan==1
		
		hold on
		plot(d_min_crop_zeroed,Fts_S_K_cons_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		hold on
		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');

		axis([ min_d_plot  max_d_plot -1.2 1.2])
 		text(1e-9,1.0, ['Max Damp: ' num2str(Damping_coefficient_ss_max), ' Ns/m'],'fontsize',12)
		text(1e-9,0.8, ['Max Damp (Crop): ' num2str(Damping_coefficient_crop_ss_max), ' Ns/m'],'fontsize',12)
		text(1e-9,0.6, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
	else
		
		axis([ d_min(1) d_min(end)  0 1.2])
		text(1e-9,0.9, ['Max Damp: ' num2str(Damping_coefficient_ss_max), ' Ns/m'],'fontsize',12)
		text(1e-9,0.7, ['Max Damp (Crop): ' num2str(Damping_coefficient_crop_ss_max), ' Ns/m'],'fontsize',12)
end

title('Damping coefficient versus dmin','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Damping coefficient Ns/m','fontsize',14)

%%%%5 Versus A/A0 %%%%%%%%%%%%%%%%%%%%%%%%

figure (count_figures+57)
hold on
box on
plot(A_norm, Damping_coefficient_r_norm,'.k','Markersize',M_size, 'displayname','Damping coefficient');
plot(A_norm, Damping_coefficient_ss_r_norm,'.c','Markersize',M_size, 'displayname','Damping coefficient:smmoth');
%% crop
plot(A_norm_crop, Damping_coefficient_crop_r_norm,'.r','Markersize',M_size, 'displayname','Damping coefficient:croped');
plot(A_norm_crop, Damping_coefficient_crop_ss_r_norm,'.b','Markersize',M_size, 'displayname','Damping coefficient:croped smooth');

title('Damping coefficient A/A0: raw','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Damping coefficient Ns/m','fontsize',14)



%%%%%%%%%%%%%%%%%%%%% Damping_coefficient Sader FI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if plot_data_processing_figures==1

figure (count_figures+24)
hold on
box on
plot(D_M_ZEROED, Fi_Dis,'.k','Markersize',M_size, 'displayname','Fi Coefficient Sader');
plot(D_M_ZEROED_CROP, Fi_Dis_crop,'.r','Markersize',M_size, 'displayname','Fi Coefficient Sader:croped');
title('Fi Coefficient Sader versus dmin','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Fi Coefficient Sader','fontsize',14)

figure (count_figures+25)
hold on
box on
plot(A_norm, Fi_Dis,'.k','Markersize',M_size, 'displayname','Fi Coefficient Sader');
plot(A_norm_crop, Fi_Dis_crop,'.r','Markersize',M_size, 'displayname','Fi Coefficient Sader:croped');
title('Fi Coefficient Sader versus A/A0','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Fi Coefficient Sader','fontsize',14)



%%%%%%%%%%%%%%%%%%%%% Damping_coefficient Increment Sader FI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure (count_figures+26)
hold on
box on
plot(D_M_ZEROED(1:end-1), Fi_Dis_Incr,'.r','Markersize',M_size, 'displayname','Fi Coefficient differential Sader');
plot(D_M_ZEROED_CROP, Fi_Dis_Incr_crop,'.c','Markersize',M_size, 'displayname','Fi Coefficient differential Sader:croped');
title('Fi Coefficient differential Sader versus dmin: raw','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Fi Coefficient differential Sader','fontsize',14)


figure (count_figures+27)
hold on
box on
plot(A_norm(1:end-1), Fi_Dis_Incr,'.r','Markersize',M_size, 'displayname','Fi Coefficient differential Sader');
plot(A_norm_crop, Fi_Dis_Incr_crop,'.c','Markersize',M_size, 'displayname','Fi Coefficient differential Sader:croped');
title('Fi Coefficient differential versus A/A0: raw','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Fi Coefficient differential Sader','fontsize',14)


end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% Resonant frequency shift normalised  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


OMEGA_AM_ss=smooth(OMEGA_AM,ss_OMEGA,'rloess');
OMEGA_AM_ss_min=min(OMEGA_AM_ss);
OMEGA_AM_norm=OMEGA_AM/abs(OMEGA_AM_ss_min);
OMEGA_AM_ss_norm=OMEGA_AM_ss/abs(OMEGA_AM_ss_min);
%%% Crop
OMEGA_AM_crop_ss=smooth(OMEGA_AM_crop,ss_OMEGA,'rloess');
OMEGA_AM_crop_ss_min=min(OMEGA_AM_crop_ss);
OMEGA_AM_crop_norm=OMEGA_AM_crop/abs(OMEGA_AM_crop_ss_min);
OMEGA_AM_crop_ss_norm=OMEGA_AM_crop_ss/abs(OMEGA_AM_crop_ss_min);

figure (count_figures+58)
hold on
box on


plot(D_M_ZEROED, OMEGA_AM_norm,'.m','Markersize',M_size, 'displayname','Normalised frequency shift');
plot(D_M_ZEROED, OMEGA_AM_ss_norm,'.g','Markersize',M_size, 'displayname','Normalised frequency shift:Smooth');

plot(D_M_ZEROED_CROP, OMEGA_AM_crop_norm,'.k','Markersize',M_size, 'displayname','Normalised frequency shift:crop');
plot(D_M_ZEROED_CROP, OMEGA_AM_crop_ss_norm,'.c','Markersize',M_size, 'displayname','Normalised frequency shift:croped:smooth');


if Sader_Katan==1
		
		hold on
		plot(d_min_crop_zeroed,Fts_S_K_cons_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		hold on
		plot(d_min_crop_sorted_zeroed,Fts_S_K_cons_norm_ss,'.b','Markersize',M_size, 'displayname','Conservative force: Sader-Katan: Smooth');

		axis([ min_d_plot  max_d_plot -1.2 1.2])
		text(1e-9,1.0, ['Nat. Freq. :' num2str(f0) '  Hz'],'fontsize',12)
 		text(1e-9,0.8, ['Min. R. Freq.: ' num2str(OMEGA_AM_crop_ss_min), ' Hz'],'fontsize',12)
		text(1e-9,0.6, ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
else
		
		axis([ d_min(1) d_min(end)  0 1.2])
		text(1e-9,1.0, ['Nat. Freq. :' num2str(f0) '  Hz'],'fontsize',12)
 		text(1e-9,0.8, ['Min. R. Freq.: ' num2str(OMEGA_AM_crop_ss_min), ' Hz'],'fontsize',12)
end

hold on
title('Normalised frequency shift versus dmin','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Normalised frequency shift','fontsize',14);       %%% from non smoothened    


%%%%% A/A0 %%%%%%%%%%%

figure (count_figures+59)
hold on
box on


plot(A_norm, OMEGA_AM,'.m','Markersize',M_size, 'displayname','Normalised frequency shift');
plot(A_norm, OMEGA_AM_ss,'.g','Markersize',M_size, 'displayname','Normalised frequency shift:Smooth');

plot(A_norm_crop, OMEGA_AM_crop,'.k','Markersize',M_size, 'displayname','Normalised frequency shift:crop');
plot(A_norm_crop, OMEGA_AM_crop_ss,'.c','Markersize',M_size, 'displayname','Normalised frequency shift:croped:smooth');


text(0.95, 0.8*max(OMEGA_AM), ['Nat. Freq. :' num2str(f0) '  Hz '],'fontsize',12);
text(0.95,0.6*max(OMEGA_AM), ['Min. R. Freq.: ' num2str(OMEGA_AM_crop_ss_min), ' Hz'],'fontsize',12);

hold on
title('Normalised frequency shift versus A/A0','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Normalised frequency shift','fontsize',14);       %%% from non smoothened    


%%%% Quantify 
if Quantification==1
	Quantification_Parameters;
end
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  END %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	else    %%% This is in case the data is not smooth, i.e. simulation or very clean experimental data 
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	
	%%%%%%%%%%%%%%
	
	A_norm=AmEx/A0;
	A_norm_crop=A_norm(Position_Zc(2,1):Position_Zc(1,1));
	Virial_Fts=k/2*AmEx.*AmEx*(1-OMEGA^2)-A0.*AmEx/2/Q.*cosine_angle_EX;
    Virial_Fts_crop=Virial_Fts(Position_Zc(2,1):Position_Zc(1,1));
	
	A_norm=AmEx/A0;
	
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Virial  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
    
%   Virial_Fts_Smth=smooth(Virial_Fts,s_Virial,'rloess');  %% 
    Virial_Fts_max=max(Virial_Fts);
    Virial_Fts_norm=Virial_Fts/Virial_Fts_max;
	Virial_Fts_norm_crop=Virial_Fts_norm(Position_Zc(2,1):Position_Zc(1,1));
%     Virial_Fts_Smth_norm=Virial_Fts_Smth/Virial_Fts_max;
    
    figure (count_figures+60)
    hold on
	box on
    plot(d_min, Virial_Fts_norm,'.r','Markersize',M_size, 'displayname','Virial_Normalised');
	plot(d_min_crop, Virial_Fts_norm_crop,'.c','Markersize',M_size, 'displayname','Virial_Normalised');
	title(' Virial versus Dmin: raw','fontsize',12)
	xlabel('dmin','fontsize',14) 
	ylabel('Normalised Virial','fontsize',14)
%   plot(d_min, Virial_Fts_Smth_norm,'.b','Markersize',3,'displayname','Virial_Normalised_Smooth');
	abs_F_adhesion=abs(F_adhesion);
	Fts_cons_crop_raw_norm=Fts_cons_crop_raw(2:end-1)/abs_F_adhesion;
	Fts_cons_crop_ss_norm=Fts_cons_crop_ss(2:end-1)/abs_F_adhesion;
	plot(d_min_crop(2:end-1),Fts_cons_crop_raw_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
	plot(d_min_crop_real(2:end-1),Fts_cons_crop_ss_norm,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');

	axis([(d_min(end)-1e-9) d_min(1) -2 2])
    text(0,1.6, ['Max Virial: ' num2str(Virial_Fts_max), ' Nm'],'fontsize',12)
	text(0,1, ['F adhesion: ' num2str(F_adhesion), ' N'],'fontsize',12)
	
	
	if Virial_Distances==1
		Find_Virial_Distance;		%% This finds the distance from 5% of positive virial until it returns to 0
	end
	
	%%%%%%%%%%%%%%%%%%%%%%%%
	
	
    figure (count_figures+61)
	hold on
	box on
	plot(A_norm, Virial_Fts_norm,'.r','Markersize',M_size, 'displayname','Virial_Normalised');
	plot(A_norm_crop, Virial_Fts_norm_crop,'.c','Markersize',M_size, 'displayname','Virial_Normalised');
	title(' Virial versus A/A0: raw','fontsize',12)
	xlabel('A/A0','fontsize',14) 
	ylabel('Normalised Virial','fontsize',14)
    
	axis([0.8  1 -4 4])
	text(0.85,1.6, ['Max Virial:' num2str(Virial_Fts_max), 'Nm'],'fontsize',12)
	
    %%%% Energy dissipation cleveland ========================================= %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if use_real_Edis==1
		Edis=Edis_T;
	else
		Edis=pi*k.*AmEx.*(A_DRIVE.*sine_angle_EX-(OMEGA/Q).*AmEx)*6.24e18;
	end
	if use_real_Edis==1
		Edis_ss=Edis;
	else
		Edis_ss=smooth(Edis,s_Edis,'rloess'); %	
	end
	Edis_max=max(Edis_ss);
	Edis_norm=Edis/Edis_max;
	Edis_norm_ss=Edis_ss/Edis_max;
	
	
	Edis_norm_crop=Edis_norm(Position_Zc(2,1):Position_Zc(1,1));
	Edis_norm_crop_ss=Edis_norm_ss(Position_Zc(2,1):Position_Zc(1,1));

	figure (count_figures+62)
	hold on
	box on
	plot(d_min, Edis_norm,'.m','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Cleveland');
	plot(d_min_crop, Edis_norm_crop,'.k','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped');
	plot(d_min, Edis_norm_ss,'.g','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Smooth');
	plot(d_min_crop, Edis_norm_crop_ss,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped:Smooth');
	%%%% Force %%%%
	plot(d_min_crop(2:end-1),Fts_cons_crop_raw_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
	plot(d_min_crop_real(2:end-1),Fts_cons_crop_ss_norm,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');
	%%%%%%%%%%%%%%%%%%%%%%%
	axis([(d_min(end)-1e-9) d_min(1) -2 2])
    text(0,1.6, ['Max Edis: ' num2str(Edis_max), ' eV'],'fontsize',12);
	text(0,1.2, ['F adhesion: ' num2str(F_adhesion), ' N'],'fontsize',12);
	%%%%%%%%%
	title('Edis versus Dmin','fontsize',12)
	xlabel('dmin','fontsize',14) 
	ylabel('Normalised Edis','fontsize',14)


	figure (count_figures+63)
	hold on
	box on
	plot(A_norm, Edis_norm,'.k','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Cleveland');
	plot(A_norm_crop, Edis_norm_crop,'.r','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped');
	plot(A_norm, Edis_norm_ss,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Cleveland');
	plot(A_norm_crop, Edis_norm_crop_ss,'.b','Markersize',M_size, 'displayname','Energy Dissipated Normalised:croped');

	text(0.9,0.2, ['Max Edis: ' num2str(Edis_max), ' eV'],'fontsize',12);
	title('Edis versus A/A0: raw','fontsize',12)
	xlabel('A/A0','fontsize',14) 
	ylabel('Normalised Edis','fontsize',14)
  


	%%%%%%%%%%%%% Energy dissipation derivative Fig 64 derivative versus amplitude dEdis/dA========================================= %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   
%   %%%%  derivative energy %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Differential_energy_norm=-(Edis_norm(2:end)-Edis_norm(1:end-1));
	Differential_energy_norm_ss=-(Edis_norm_ss(2:end)-Edis_norm_ss(1:end-1));
	Differential_energy_norm_crop=Differential_energy_norm(Position_Zc(2,1):Position_Zc(1,1));
	Differential_energy_norm_crop_ss=Differential_energy_norm_ss(Position_Zc(2,1):Position_Zc(1,1));
	
	Differential_Amplitude=A_norm(2:end)-A_norm(1:end-1);
	Differential_Amplitude_crop=Differential_Amplitude(Position_Zc(2,1):Position_Zc(1,1));
	
	Derivative_norm=Differential_energy_norm./Differential_Amplitude;
	Derivative_norm_crop=Derivative_norm(Position_Zc(2,1):Position_Zc(1,1));
	
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	%%%% NANS ETC %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%  curve raw %%%%
	DUMMY_YY=zeros(length(Derivative_norm));
	DUMMY_XX=zeros(length(d_min(1:end-1)));
	DUMMY_YY=Derivative_norm;
	DUMMY_XX=d_min(1:end-1);

	GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
	Derivative_real=DUMMY_YY_real;
	d_real=DUMMY_XX_real;
	
	%%%  curve Edis smooth %%%%
	DUMMY_YY=zeros(length(Derivative_norm_crop));
	DUMMY_XX=zeros(length(d_min_crop));
	DUMMY_YY=Derivative_norm_crop;
	DUMMY_XX=d_min_crop;

	GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
	Derivative_real_crop=DUMMY_YY_real;
	d_real_crop=DUMMY_XX_real;
	

	Derivative_real_ss=smooth(Derivative_real,s_Derivative_A,'rloess'); %
	Derivative_real_crop_ss=smooth(Derivative_real_crop,s_Derivative_A,'rloess');
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%% Looking for maxima of raw data all curve %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	Der_max=max(Derivative_real_ss(floor(0.05*(length(Derivative_real_ss))):0.9*(length(Derivative_real_ss))));
	Der_min=min(Derivative_real_crop_ss(floor(0.05*(length(Derivative_real_crop_ss))):floor(0.9*(length(Derivative_real_crop_ss)))));
	if (abs(Der_min)>abs(Der_max))
		Max_Der=Der_min;
		Der_maxima=abs(Der_min);
	else
		Max_Der=Der_max;
		Der_maxima=abs(Der_max);
	end
	%%% Crop %%%%%%%%%%
	Der_max_crop=max(Derivative_real_crop_ss(floor(0.05*(length(Derivative_real_crop_ss))):0.9*(length(Derivative_real_crop_ss))));
	Der_min_crop=min(Derivative_real_crop_ss(floor(0.05*(length(Derivative_real_crop_ss))):floor(0.9*(length(Derivative_real_crop_ss)))));
	if (abs(Der_min_crop)>abs(Der_max_crop))
		Max_Der_crop=Der_min_crop;
		Der_maxima_crop=abs(Der_min_crop);
	else
		Max_Der_crop=Der_max_crop;
		Der_maxima_crop=abs(Der_max_crop);
	end
	
	%%% Normalise %%%
	

	Derivative_norm_norm=Derivative_norm/Der_maxima;
	Derivative_real_ss_norm=Derivative_real_ss/Der_maxima;
	
	Derivative_norm_norm_crop=Derivative_norm_crop/Der_maxima_crop;
	Derivative_real_ss_norm_crop=Derivative_real_crop_ss/Der_maxima_crop;
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	figure (count_figures+64)
	hold on
	box on
	plot(d_min(1:end-1), Derivative_norm_norm,'.m','Markersize',M_size, 'displayname','Energy derivative Normalised:');
	plot(d_real, Derivative_real_ss_norm,'.g','Markersize',M_size, 'displayname','Energy derivative Normalised:Smooth');
	%%%% croped 
	plot(d_min_crop, Derivative_norm_norm_crop,'.k','Markersize',M_size, 'displayname','Energy derivative Normalised:croped');
	plot(d_real, Derivative_real_ss_norm_crop,'.c','Markersize',M_size, 'displayname','Energy derivative Normalised:croped');
	%%%% Force %%%%
	plot(d_min_crop(2:end-1),Fts_cons_crop_raw_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
	plot(d_min_crop_real(2:end-1),Fts_cons_crop_ss_norm,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');
	%%%%%%%%%%%%%%%%%%%%%%%
	axis([(d_min(end)-1e-9) d_min(1) -2 2])
    text(0,1.8, ['Max der.(norm): ' num2str(Max_Der), ' eV/nm'],'fontsize',12);
	text(0,1.4, ['Max der. (norm) crop: ' num2str(Max_Der_crop), ' eV/nm'],'fontsize',12);
	text(0,1, ['F adhesion: ' num2str(F_adhesion), ' N'],'fontsize',12);

	
	title('Edis derivative versus dmin: dE*/dA*','fontsize',12);
	xlabel('dmin','fontsize',14);
	ylabel('Normalised Edis Derivative verus dE*/dA*','fontsize',14);
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% End fig 64 %%%%%%%%%%%%%
	
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%%%%%%%%%%%%%%%    Edis/ddmin derivative as function of dmin  FIG 65 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	Differential_energy_norm_r=Differential_energy_norm(1:Derivative_points_sim:end);
	Differential_energy_norm_r_ss=Differential_energy_norm_ss(1:Derivative_points_sim:end);
	derivative_2=(d_min(2:Derivative_points_sim:end)-d_min(1:Derivative_points_sim:end-1));
	derivative_3=Differential_energy_norm_r./derivative_2;
	derivative_3_ss=Differential_energy_norm_r_ss./derivative_2;
	d_d_min=d_min;
	d_d_min_r=d_d_min(1:Derivative_points_sim:end);
	
	%%%% NANS ETC %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%  curve raw %%%%
	DUMMY_YY=zeros(length(derivative_3));
	DUMMY_XX=zeros(length(d_d_min_r));
	DUMMY_YY=derivative_3;
	DUMMY_XX=d_d_min_r(1:end-1);

	GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
	Derivative_dmin_real=DUMMY_YY_real;
	d_dmin_real=DUMMY_XX_real;
	
	%%%  curve Edis smooth %%%%
	DUMMY_YY=zeros(length(derivative_3_ss));
	DUMMY_XX=zeros(length(d_d_min_r));
	DUMMY_YY=derivative_3_ss;
	DUMMY_XX=d_d_min_r(1:end-1);

	GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
	Derivative_dmin_real_Edis_ss=DUMMY_YY_real;
	d_dmin_real_Edis=DUMMY_XX_real;
	

	Derivative_dmin_real_ss=smooth(Derivative_dmin_real,s_Derivative,'rloess'); %
	Derivative_dmin_real_Edis_ss_ss=smooth(Derivative_dmin_real_Edis_ss,s_Derivative_Edis,'rloess');
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%% Looking for maxima of raw data smoothened %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	Der_sim_max=max(Derivative_dmin_real_ss(floor(0.05*(length(Derivative_dmin_real_ss))):0.9*(length(Derivative_dmin_real_ss))));
	Der_sim_min=min(Derivative_dmin_real_ss(floor(0.05*(length(Derivative_dmin_real_ss))):floor(0.9*(length(Derivative_dmin_real_ss)))));
	if (abs(Der_sim_min)>abs(Der_sim_max))
		Maxima_Edis=Der_sim_min;
		Der_Edis_maxima=abs(Der_sim_min);
	else
		Maxima_Edis=Der_sim_max;
		Der_Edis_maxima=abs(Der_sim_max);
	end
	%%%%%% ALl curve %%%%
	Der_sim_max_ss=max(Derivative_dmin_real_Edis_ss_ss(floor(0.05*(length(Derivative_dmin_real_Edis_ss_ss))):0.9*(length(Derivative_dmin_real_Edis_ss_ss))));
	Der_sim_min_ss=min(Derivative_dmin_real_Edis_ss_ss(floor(0.05*(length(Derivative_dmin_real_Edis_ss_ss))):floor(0.9*(length(Derivative_dmin_real_Edis_ss_ss)))));
	if (abs(Der_sim_min_ss)>abs(Der_sim_max_ss))
		Maxima_Edis_ss=Der_sim_min_ss;
		Der_Edis_maxima_ss=abs(Der_sim_min_ss);
	else
		Maxima_Edis_ss=Der_sim_max_ss;
		Der_Edis_maxima_ss=abs(Der_sim_max_ss);
	end
	
	%%% Normalise %%%
	
	Derivative_dmin_real_norm=Derivative_dmin_real/Der_Edis_maxima;
	Derivative_dmin_real_ss=Derivative_dmin_real_ss/Der_Edis_maxima;
	
	
	Derivative_dmin_real_Edis_ss_norm=Derivative_dmin_real_Edis_ss/Der_Edis_maxima_ss;
	Derivative_dmin_real_Edis_ss_ss_norm=Derivative_dmin_real_Edis_ss_ss/Der_Edis_maxima_ss;
	
	figure (count_figures+65)
	hold on
	box on
	plot(d_dmin_real_Edis, Derivative_dmin_real_Edis_ss_norm,'.m','Markersize',M_size, 'displayname','Energy (smooth)  derivative Normalised:');
	plot(d_dmin_real_Edis, Derivative_dmin_real_Edis_ss_ss_norm,'.g','Markersize',M_size, 'displayname','Energy (smooth) derivative Normalised:Smooth');
  	plot(d_dmin_real, Derivative_dmin_real_norm,'.k','Markersize',M_size, 'displayname','Energy derivative Normalised:Normalised');
	plot(d_dmin_real, Derivative_dmin_real_ss,'.c','Markersize',M_size, 'displayname','Energy derivative Normalised:Normalised:Smooth');

	%%%% Force %%%%
	plot(d_min_crop(2:end-1),Fts_cons_crop_raw_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
	plot(d_min_crop_real(2:end-1),Fts_cons_crop_ss_norm,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');
	%%%%%%%%%%%%%%%%%%%%%%%
	axis([(d_min(end)-1e-9) d_min(1) -2 2])
    text(0,1.8, ['Max der.(norm): ' num2str(Der_Edis_maxima/10e6), ' keV/nm'],'fontsize',12);
	text(0,1.4, ['Max der. (norm) smooth: ' num2str(Der_Edis_maxima_ss/10e6), ' keV/nm'],'fontsize',12);
	text(0,1, ['F adhesion: ' num2str(F_adhesion), ' N'],'fontsize',12);
	
	title('Edis derivative versus dmin dE*/ddmin*','fontsize',12)
	xlabel('dmin','fontsize',14) 
	ylabel('Normalised Edis Derivative dE*/ddmin*','fontsize',14)
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%%%%%%%%%%%%%%%%%%%%%% dEdis/dA%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	figure (count_figures+66)
	hold on
	box on
	
	
	%%%%%%%%%%%%%%%%%%%%% NANS ETC %%%%%%%%%%%%%
		%%%  curve raw %%%%
	DUMMY_YY=zeros(length(Derivative_norm));
	DUMMY_XX=zeros(length(A_norm(1:end-1)));
	DUMMY_YY=Derivative_norm;
	DUMMY_XX=A_norm(1:end-1);

	GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
	Derivative_real_A=DUMMY_YY_real;
	A_real_A=DUMMY_XX_real;
	
	%%%  curve Edis smooth %%%%
	DUMMY_YY=zeros(length(Derivative_norm_crop));
	DUMMY_XX=zeros(length(A_norm(1:end-1)));
	DUMMY_YY=Derivative_norm_crop;
	DUMMY_XX=A_norm(1:end-1);
	
	GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
	Derivative_real_crop_A=DUMMY_YY_real;
	A_real_crop_A=DUMMY_XX_real;
	

	Derivative_real_ss_A=smooth(Derivative_real_A,s_Derivative_A_A,'rloess'); %
	Derivative_real_crop_ss_A=smooth(Derivative_real_crop_A,s_Derivative_A_A_crop,'rloess');
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%% Looking for maxima of raw data all curve %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	Der_max_A=max(Derivative_real_ss_A(floor(0.05*(length(Derivative_real_ss_A))):0.9*(length(Derivative_real_ss_A))));
	Der_min_A=min(Derivative_real_ss_A(floor(0.05*(length(Derivative_real_ss_A))):floor(0.9*(length(Derivative_real_ss_A)))));
	if (abs(Der_min_A)>abs(Der_max_A))
		Max_Der_A=Der_min_A;
		Der_maxima_A=abs(Der_min_A);
	else
		Max_Der_A=Der_max_A;
		Der_maxima_A=abs(Der_max_A);
	end
	%%% Crop %%%%%%%%%%
	Der_max_crop_A=max(Derivative_real_crop_ss_A(floor(0.05*(length(Derivative_real_crop_ss_A))):0.9*(length(Derivative_real_crop_ss_A))));
	Der_min_crop_A=min(Derivative_real_crop_ss_A(floor(0.05*(length(Derivative_real_crop_ss_A))):floor(0.9*(length(Derivative_real_crop_ss_A)))));
	if (abs(Der_min_crop_A)>abs(Der_max_crop_A))
		Max_Der_crop_A=Der_min_crop_A;
		Der_maxima_crop_A=abs(Der_min_crop_A);
	else
		Max_Der_crop_A=Der_max_crop_A;
		Der_maxima_crop_A=abs(Der_max_crop_A);
	end
	
	%%% Normalise %%%
	

	Derivative_norm_norm_A=Derivative_norm/Der_maxima_A;
	Derivative_real_ss_norm_A=Derivative_real_ss/Der_maxima_A;
	
	Derivative_norm_norm_crop_A=Derivative_norm_crop/Der_maxima_crop_A;
	Derivative_real_ss_norm_crop_A=Derivative_real_crop_ss/Der_maxima_crop_A;
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	hold on  %% Fig 66
	plot(A_norm(1:end-1), Derivative_norm_norm_A,'.m','Markersize',M_size, 'displayname','Energy derivative Normalised:');
	plot(A_real_A, Derivative_real_ss_norm_A,'.g','Markersize',M_size, 'displayname','Energy derivative Normalised:Smooth');
	%%%% croped 
	plot(A_norm_crop, Derivative_norm_norm_crop_A,'.k','Markersize',M_size, 'displayname','Energy derivative Normalised:croped');
	plot(A_real_crop_A(1:end-1), Derivative_real_ss_norm_crop_A,'.c','Markersize',M_size, 'displayname','Energy derivative Normalised:croped');
	
	axis([A_norm(end) 1 -2 2])
    text(0.8,1, ['Max der.(norm): ' num2str(Max_Der_A/10e6), ' keV/nm'],'fontsize',12);
	text(0.8,1.6, ['Max der. (norm) crop: ' num2str(Max_Der_crop_A/10e6), ' keV/nm'],'fontsize',12);
	
	title('Edis derivative versus A/A0','fontsize',12)
	xlabel('A/A0','fontsize',14) 
	ylabel('Normalised Edis Derivative','fontsize',14)
	
%%%%%%%%%%%%%%%%%%%%% Phase difference %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


ANGLE_CONSERVATIVE=asin(AmEx/A0)*180/pi;
for iii=1:length(PhEx)
	if PhEx(iii,1)>90
		ANGLE_CONSERVATIVE(iii, 1)=180-ANGLE_CONSERVATIVE(iii,1);
	end
end

ANGLE_CONSERVATIVE_crop=ANGLE_CONSERVATIVE(Position_Zc(2,1):Position_Zc(1,1));
PhEx_crop=PhEx(Position_Zc(2,1):Position_Zc(1,1));

figure (count_figures+67)
hold on
box on
plot(A_norm, ANGLE_CONSERVATIVE,'.r','Markersize',M_size, 'displayname','Conservative phase');
plot(A_norm_crop, ANGLE_CONSERVATIVE_crop,'.c','Markersize',M_size, 'displayname','Conservative:croped');
plot(A_norm, PhEx,'.b','Markersize',M_size, 'displayname','phase');
plot(A_norm_crop, PhEx_crop,'.k','Markersize',M_size, 'displayname','phase:croped');
title('Conservative and dissipative phase branches:A/A0','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Phase','fontsize',14)

figure (count_figures+68)
hold on
box on
plot(d_min, ANGLE_CONSERVATIVE,'.r','Markersize',M_size, 'displayname','Conservative phase');
plot(d_min_crop, ANGLE_CONSERVATIVE_crop,'.c','Markersize',M_size, 'displayname','Conservative:croped');
plot(d_min, PhEx,'.b','Markersize',M_size, 'displayname','phase');
plot(d_min_crop, PhEx_crop,'.k','Markersize',M_size, 'displayname','phase:croped');
title('Conservative and dissipative phase branches:dmin','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Phase','fontsize',14)



%%%%%% Here do %%%% Phase difference and energy times phase difference %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% Phase difference %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Phase_difference=abs(ANGLE_CONSERVATIVE-PhEx);
Phase_difference_max=max(Phase_difference);
Phase_difference_crop=Phase_difference(Position_Zc(2,1):Position_Zc(1,1));

Phase_difference_norm=Phase_difference/Phase_difference_max;
Phase_difference_norm_crop=Phase_difference_norm(Position_Zc(2,1):Position_Zc(1,1));

Phase_Energy=Edis_norm.*Phase_difference_norm;
Phase_Energy_max=max(Phase_Energy);
Phase_Energy_norm=Phase_Energy/Phase_Energy_max;
Phase_Energy_norm_crop=Phase_Energy_norm(Position_Zc(2,1):Position_Zc(1,1));

%%%%%%%%%%%%%% Phase difference %%%%%%%%%%%%%%%%%%%

figure (count_figures+69)  %% Phase diff dmin 
hold on
box on
plot(d_min, Phase_difference_norm,'.r','Markersize',M_size, 'displayname','Phase difference');
plot(d_min_crop, Phase_difference_norm_crop,'.c','Markersize',M_size, 'displayname','Phase difference:croped');
text(0,0.6, ['Max Phase Diff:' num2str(Phase_difference_max)],'fontsize',12)
text(0,1.2, ['F adhesion: ' num2str(F_adhesion), ' N'],'fontsize',12);
%%%% Force %%%%
plot(d_min_crop(2:end-1),Fts_cons_crop_raw_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
plot(d_min_crop_real(2:end-1),Fts_cons_crop_ss_norm,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');
	%%%%%%%%%%%%%%%%%%%%%%%
axis([(d_min(end)-1e-9) d_min(1) -2 2])


title('Phase difference dmin: raw','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Phase difference: Normalised','fontsize',14)

figure (count_figures+70)   %% Phase diff A/A0 
hold on
box on
plot(A_norm, Phase_difference_norm,'.r','Markersize',M_size, 'displayname','Phase difference');
plot(A_norm_crop, Phase_difference_norm_crop,'.c','Markersize',M_size, 'displayname','Phase difference:croped');
text(0.95*max(A_norm),0.9, ['Max Phase Diff:' num2str(Phase_difference_max)],'fontsize',12)
axis([A_norm(end) 1 -2 2])
title('Phase difference A/A0: raw','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Phase difference: Normalised','fontsize',14)




%%%%%%%%%%%%%% Phase difference times energy %%%%%%%%%%%%%%%%%%%


figure (count_figures+71)
hold on
box on
plot(d_min, Phase_Energy_norm,'.r','Markersize',M_size, 'displayname','Phase difference*Energy');
plot(d_min_crop, Phase_Energy_norm_crop,'.c','Markersize',M_size, 'displayname','Phase difference*Energy:croped');
text(0,1.6, ['Max Phase Energy: ' num2str(Phase_Energy_max)],'fontsize',12)
text(0,1, ['F adhesion: ' num2str(F_adhesion), ' N'],'fontsize',12);
%%%% Force %%%%
plot(d_min_crop(2:end-1),Fts_cons_crop_raw_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
plot(d_min_crop_real(2:end-1),Fts_cons_crop_ss_norm,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');
	%%%%%%%%%%%%%%%%%%%%%%%
axis([(d_min(end)-1e-9) d_min(1) -2 2])

title('Phase difference*Energy dmin: raw','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Phase difference*Energy: Normalised','fontsize',14)

figure (count_figures+72)
hold on
box on 
plot(A_norm, Phase_Energy_norm,'.r','Markersize',M_size, 'displayname','Phase difference*Energy');
plot(A_norm_crop, Phase_Energy_norm_crop,'.c','Markersize',M_size, 'displayname','Phase difference*Energy:croped');
text(0.9*max(A_norm),1, ['Max Phase Energy: ' num2str(Phase_Energy_max)],'fontsize',12)
title('Phase difference*Energy A/A0','fontsize',12)
axis([A_norm(end) 1 -2 2])
xlabel('A/A0','fontsize',14) 
ylabel('Phase difference*Energy: Normalised','fontsize',14)



%%%%%%%%%%%%%%%%%%%%% Damping_coefficient %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Damping_coefficient_max=max(Damping_coefficient);
Damping_coefficient_crop_max=max(Damping_coefficient);


figure (count_figures+73)
hold on
box on
plot(d_min, Damping_coefficient/Damping_coefficient_max,'.r','Markersize',M_size, 'displayname','Damping coefficient');
plot(d_min_crop, Damping_coefficient_crop/Damping_coefficient_crop_max,'.c','Markersize',M_size, 'displayname','Damping coefficient:croped');
title('Damping coefficient (norm) versus dmin: raw','fontsize',12);
title('Damping coefficient versus dmin: raw','fontsize',12);

text(0,1.6, ['Max damping coeff (crop): ' num2str(Damping_coefficient_crop_max), ' Ns/m'],'fontsize',12);
text(0,1.2, ['Max damping coeff: ' num2str(Damping_coefficient_max), ' Ns/m'],'fontsize',12);
text(0,0.8, ['F adhesion: ' num2str(F_adhesion), ' N'],'fontsize',12);
%%%% Force %%%%
plot(d_min_crop(2:end-1),Fts_cons_crop_raw_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
plot(d_min_crop_real(2:end-1),Fts_cons_crop_ss_norm,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');
	%%%%%%%%%%%%%%%%%%%%%%%
axis([(d_min(end)-1e-9) d_min(1) -2 2])

xlabel('dmin','fontsize',14) 
ylabel('Damping coefficient Ns/m','fontsize',14)

%%%%%%%%%%%%% A/A0 %%%%%%%%%%%%%%%%%

figure (count_figures+74)
hold on
box on

plot(A_norm, Damping_coefficient/Damping_coefficient_max,'.r','Markersize',M_size, 'displayname','Damping coefficient');
plot(A_norm_crop, Damping_coefficient_crop/Damping_coefficient_crop_max,'.c','Markersize',M_size, 'displayname','Damping coefficient:croped');
axis([A_norm(end) 1 -2 2])
text(0.8,1.6, ['Max damping coeff (crop): ' num2str(Damping_coefficient_crop_max), ' Ns/m'],'fontsize',12);
text(0.8,1.2, ['Max damping coeff: ' num2str(Damping_coefficient_max), ' Ns/m'],'fontsize',12);

title('Damping coefficient (norm) A/A0: raw','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Damping coefficient Ns/m','fontsize',14)



%%%%%%%%%%%%%%%%%%%%% Damping_coefficient Sader FI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Fi_Dis_crop=Fi_Dis(Position_Zc(2,1):Position_Zc(1,1));
Fi_Dis_Incr_crop=Fi_Dis_Incr(Position_Zc(2,1):Position_Zc(1,1));   % This is raw

figure (count_figures+75)
hold on
box on
plot(A_norm, Fi_Dis,'.r','Markersize',M_size, 'displayname','Fi Coefficient Sader');
plot(A_norm_crop, Fi_Dis_crop,'.c','Markersize',M_size, 'displayname','Fi Coefficient Sader:croped');
title('Fi Coefficient Sader versus A/A0','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Fi Coefficient Sader','fontsize',14)


figure (count_figures+76)
hold on
box on
plot(d_min, Fi_Dis,'.r','Markersize',M_size, 'displayname','Fi Coefficient Sader');
plot(d_min_crop, Fi_Dis_crop,'.c','Markersize',M_size, 'displayname','Fi Coefficient Sader:croped');
title('Fi Coefficient Sader versus A/A0: raw','fontsize',12)
title('Fi Coefficient Sader versus dmin','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Fi Coefficient Sader','fontsize',14)


%%%%%%%%%%%%%%%%%%%%% Damping_coefficient Increment Sader FI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



figure (count_figures+77)
hold on
box on
plot(A_norm(1:end-1), Fi_Dis_Incr,'.r','Markersize',M_size, 'displayname','Fi Coefficient differential Sader');
plot(A_norm_crop, Fi_Dis_Incr_crop,'.c','Markersize',M_size, 'displayname','Fi Coefficient differential Sader:croped');
title('Fi Coefficient differential versus A/A0: raw','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Fi Coefficient differential Sader','fontsize',14)


figure (count_figures+78)
hold on
box on
plot(d_min(1:end-1), Fi_Dis_Incr,'.r','Markersize',M_size, 'displayname','Fi Coefficient differential Sader');
plot(d_min_crop, Fi_Dis_Incr_crop,'.c','Markersize',M_size, 'displayname','Fi Coefficient differential Sader:croped');
title('Fi Coefficient differential Sader versus dmin: raw','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Fi Coefficient differential Sader','fontsize',14)




%%%%%%%%%%%%%%%%%%%%% Resonant frequency shift normalised  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

OMEGA_AM_min=min(OMEGA_AM);
OMEGA_AM_crop_min=min(OMEGA_AM_crop);
OMEGA_AM_norm=OMEGA_AM/abs(OMEGA_AM_min);
OMEGA_AM_crop_norm=OMEGA_AM_crop/abs(OMEGA_AM_crop_min);

figure (count_figures+58)
hold on
box on
plot(d_min, OMEGA_AM_norm,'.r','Markersize',M_size, 'displayname','Normalised frequency shift');
plot(d_min_crop, OMEGA_AM_crop_norm,'.c','Markersize',M_size, 'displayname','Normalised frequency shift:croped');

text(0,1.6, ['Nat. Freq. norm: ' num2str(f0) '  Hz '],'fontsize',12);
text(0,1.2, ['Min. Freq. norm (crop): ' num2str(OMEGA_AM_crop_min) '  Hz '],'fontsize',12);
text(0,0.8, ['Min. Freq. :' num2str(OMEGA_AM_min) '  Hz '],'fontsize',12);
text(0,0.4, ['F adhesion: ' num2str(F_adhesion), ' N'],'fontsize',12);
%%%% Force %%%%
plot(d_min_crop(2:end-1),Fts_cons_crop_raw_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
plot(d_min_crop_real(2:end-1),Fts_cons_crop_ss_norm,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');
	%%%%%%%%%%%%%%%%%%%%%%%
axis([(d_min(end)-1e-9) d_min(1) -2 2])

hold on
title('Normalised frequency shift versus dmin','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Normalised frequency shift','fontsize',14);       %%% from non smoothened    BEST


figure (count_figures+59)
hold on
box on
plot(A_norm, OMEGA_AM_norm,'.r','Markersize',M_size, 'displayname','Normalised frequency shift');
plot(A_norm_crop, OMEGA_AM_crop_norm,'.c','Markersize',M_size, 'displayname','Normalised frequency shift:croped');
text(0.8,3, ['Nat. Freq. :' num2str(f0) '  Hz '],'fontsize',12);
text(0.8,2, ['Min. Freq. norm (crop) :' num2str(OMEGA_AM_crop_min) '  Hz '],'fontsize',12);
text(0.8,1, ['Min. Freq. norm :' num2str(OMEGA_AM_min) '  Hz '],'fontsize',12);

axis([A_norm(end) 1 -2 6])

hold on
title('Normalised frequency shift versus A/A0','fontsize',12)
xlabel('A/A0','fontsize',14) 
ylabel('Normalised frequency shift','fontsize',14);       %%% from non smoothened  



%%%%% Plot A/A0 versus dmin Fig. 57 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Min_Amplitude_norm=min(A_norm);
Range_A_Total=A_norm(1)-A_norm(end);
Range_A=1-A_norm;
Range_A_crop=1-A_norm_crop;

figure (count_figures+57)
hold on
box on
plot(d_min,(Range_A_Total-Range_A)/Range_A_Total, '.k', 'Markersize',M_size, 'displayname','Amplitud A/A0');    %%% 'fontsize',14,  ,  , 
plot(d_min_crop,(Range_A_Total-Range_A_crop)/Range_A_Total, '.m', 'Markersize',M_size, 'displayname','Amplitud A/A0');   
axis([(d_min(end)-1e-9) d_min(1) -1.4  1.4])
title(' Amplitud (normalised) versus dmin','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Amplitude','fontsize',14)
	
% %% derivative and force %%%
% %plot(d_min(1:end-1), Derivative_norm_norm,'.g','Markersize',M_size, 'displayname','Energy derivative Normalised:');
 plot(d_real, Derivative_real_ss_norm,'.g','Markersize',M_size, 'displayname','Energy derivative Normalised A/A0:Smooth');
% %%%% croped 
% %plot(d_min_crop, Derivative_norm_norm_crop,'.k','Markersize',M_size, 'displayname','Energy derivative Normalised:croped');
%plot(d_real, Derivative_real_ss_norm_crop,'.c','Markersize',M_size, 'displayname','Energy derivative Normalised A/A0:croped');
% 
% %%%% Derivative dmin %%%%%%%%%%%%%%%%%%%
 plot(d_dmin_real, Derivative_dmin_real_ss,'.c','Markersize',M_size, 'displayname','Energy derivative Normalised dE*/dmin:Normalised');
% %%%% Force %%%%
 plot(d_min_crop(2:end-1),Fts_cons_crop_raw_norm,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
 plot(d_min_crop_real(2:end-1),Fts_cons_crop_ss_norm,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');

axis([ (d_min(end)-1e-9) d_min(1) -1.2 1.2])

text(1e-9,-1, ['Min Amplitude: ' num2str(Min_Amplitude_norm*A0*1e9), ' nm'],'fontsize',10);
text(1e-9,-0.8, ['Max der. (dE*/ddmin) smooth: ' num2str(Der_Edis_maxima_ss/10e6), ' keV/nm'],'fontsize',10);
text(1e-9,-0.6, ['Max der. (dE*/dA*) crop : ' num2str(Max_Der_crop), ' eV/nm'],'fontsize',10);
text(1e-9,-0.4, ['A0 :' num2str(A0*1e9) '  nm'],'fontsize',10);



end  % end of choosing smoothening with experimental or as above, no smoothening, i.e. simulation 



	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Distance studies %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


if Attractive_Distances==1
	; 
end

