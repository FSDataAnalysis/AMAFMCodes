% S Santos 2014 Sept #
% This file does statistics with the elastic modulus

load NumberOfFiles.mat

EE_M_NN=[];
EE_M_AL=[];

for ii=1:c_mine
  
        strFileSpec = sprintf( 'Elasticity%u', ii );
        load ( strFileSpec )
        
        EE_M_NN=cat(1, EE_M_NN,  E_m_NN);
        EE_M_AL=cat(1, EE_M_AL,  E_m_Al);
        
end


figure (201) 

boxplot(EE_M_NN)

Mean_EM=mean(EE_M_NN)
SD_EM=std(EE_M_NN)
