% clear all; clc; close all;
% load foo;


Matrix_values=[];

% prompt= {'Multiple ref:','Number of points:', 'Initial:','Final:'};
% dlg_title='Input Data';
% num_lines=1;

%%%% Modification S Santos 2014 Nov 07 
%%%% Disambiguation:

%%%% Multiple ref=0 then you look for Work of adhesion at Initial and delta FAD at final

%%%% Initial: 0.8 means find deltaFAD at 0.8FAD as defined in:
%%%% Amadei, C. A., Tang, T. C., Chiesa, M. & Santos, S.,  The Journal of Chemical Physics 139, 084708 (2013).


%%%% Multiple ref=1 then you look for Work of adhesion and delta FAD for
%%%% Number of points 

%%%% Definition of Number of points: Number of points minimum is 2.
%%%% If Number of points = 2 then work of adhesion and dFAD at Initial and Final
%%%% points. 

%%%% If Number of points >2 then it looks for other:
%%%% Example, Number of points=3 
%%%% Initial=0.05 
%%%% FInal= 0.8
%%%% (0.8-0.05)/2=0.375. Then it looks at: 0.05, 0.375 and 0.8. 



multiple=str2double(answer(1));
Npoints=str2double(answer(2));
initial_value=str2double(answer(3));
final_value=str2double(answer(4));

if multiple==0   
    dumb_loop=2;
    CL_vector=[initial_value final_value];
    
elseif multiple==1  
    dumb_loop=Npoints;
    
    intervals_in_between=(final_value-initial_value)/(Npoints-1);
    
    
    CL_vector=initial_value:intervals_in_between:final_value;
    
else  % it just calculates the   
    dumb_loop=2; 
end



for jjj=1:dumb_loop

    CL =CL_vector(jjj);

    ResulrMat = [];
    Res_cnt = 1;
    FileList = dir;
    FileList(1:2,:)=[];
    FolderList;
    DirLstL_0 = DirName;


    a = cd;
    b = strcat(a,'\',DirLstL_0);

    FileList = dir(cell2mat(b));
    FileList(1:2,:)=[];
    FolderList;
    DirLstL_1{1} = [b, DirName];
   
    Lp_Dir_lst = DirLstL_1;

    for Lv = 1:3
        DirLstL_Int = []; 
% 
%         Clp2=1;
        for Clp2 = 1:size(Lp_Dir_lst,1)

%                Lp2=2;
            for Lp2 = 2:length(Lp_Dir_lst{Clp2,1})
                
                DirName=[];
                d = strcat(Lp_Dir_lst{Clp2,1}(1),'\',Lp_Dir_lst{Clp2,1}(Lp2));

                FileList = dir(cell2mat(d));
                FileList(1:2,:)=[];



                FolderList;

                if isempty(DirName)==1
                continue;
                end

                DirLstL_trans{Lp2-1,1} = [d, DirName];
            end
            
            DirLstL_Int = [DirLstL_Int;DirLstL_trans];
            DirLstL_trans= [];
        end

        %===============  Step 2.1  ======================================= 

        Lp_Dir_lst = DirLstL_Int;

    end

    ResulrMat(:,2)=ResulrMat(:,2).*ResulrMat(:,1);  %%% turn into work of adhesion in Joules
    
    Matrix_values(:,:,jjj)=ResulrMat;
    
   
end

close all;

    