 if NonLinear_ElasticM==1 %%% Non linear fit for elastic modulus


    y=e_load_IU;
    dy = y*CONFIDENCE_INTERVAL_ElasticM;

    xx_e=4/3*(R^(0.5))*(e_Indentation_IU.^(1.5));
    x=[xx_e];    % 

    %formula converted to
    %The inline version
    func = inline('p(1)*x(:,1)','p','x');   % %%% Here p is the elastic modulus

    
    
    p0 = Chauvenete_ElasticM_mean;

    %To detect the sensitivity of the fit to starting parameter guess,
    %the fit is run a number of times.
    %each fit is plotted and each parameter plotted as a histogram
    Nrepeat=20;
    %each parameter is varied by a normal distribution with
    %mean equal to the starting guess and std.dev. equal to
    %sd*mean
    sd = 0.3;
    %histogram zoom factor (how many std dev to show)
    zfactor = 2;
    %parameter outlier cuttoff: lowest and highest N estimates are removed
    outcut=10;
    %========================================================
    %END settable inputs
    %========================================================
    terms=1;
    %list of all parameter outputs to use in histogram
    pList_single=zeros(Nrepeat,terms);

    flag_complex_single=0;
    
    for rep =1:Nrepeat
        %     rep

        %form the new randomized start vector
        p = [p0(1)*(1+sd*randn)];
        %do the fit
        [p,r,j] = nlinfit(x,y,func,p);
        %copy fit to list
        pList_single(rep,:) = p';

        %get parameter errors
            
        if (isreal(r)==0||isreal(p)==0||isreal(j==0))    % error
        
%             c95 = nlparci(real(p),real(r),real(j));
%             [yp, ci] = nlpredci(func,x,p,r,j);
            flag_complex_single=1;
%             break;

        else 
            c95 = nlparci(p,r,j);
            [yp, ci] = nlpredci(func,x,p,r,j);
        end

    end

    if isempty(pList_single)
    
        output_ElasticM_mean_single=Chauvenete_ElasticM_mean;
        output_ElasticM_std_single=Chauvenete_ElasticM_std;
        flag_complex_single=1;
    else
        
        output_ElasticM_mean_single=mean(pList_single);
        output_ElasticM_std_single=std(pList_single);
        flag_complex_single=0;
    end

 end